export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isError?: boolean;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface QuizData {
  topic: string;
  questions: QuizQuestion[];
}

export interface StudySession {
  time: string;
  subject: string;
  topic: string;
  activity: string;
}

export interface DailyPlan {
  day: string;
  sessions: StudySession[];
}

export interface StudyPlanData {
  weeklySchedule: DailyPlan[];
  tips: string[];
}

export interface GameQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  fact: string;
}

export interface BubbleGameLevel {
  topic: string;
  questions: { id: number; text: string; answer: string }[];
  decoys: string[];
}

export interface ScanResult {
  topic: string;
  description: string;
  keyPoints: string[];
  visualType: 'COSMOS' | 'ATOMIC' | 'BIOLOGY' | 'GEOMETRY' | 'HISTORY';
}

export enum AppView {
  DASHBOARD = 'DASHBOARD',
  TUTOR = 'TUTOR',
  PLANNER = 'PLANNER',
  QUIZ = 'QUIZ',
  PARENT_CONNECT = 'PARENT_CONNECT',
  THREE_D_LEARNING = 'THREE_D_LEARNING',
  GAME = 'GAME',
  AI_SCANNER = 'AI_SCANNER',
}