import { GoogleGenAI, Type } from "@google/genai";
import { Message, StudyPlanData, QuizData, GameQuestion, BubbleGameLevel, ScanResult } from '../types';

// Initialize Gemini Client
// CRITICAL: process.env.API_KEY is injected by the environment.
// We use a safe check for 'process' to avoid ReferenceError in browser-only environments.
const apiKey = (typeof process !== 'undefined' && process.env) ? process.env.API_KEY : '';
const ai = new GoogleGenAI({ apiKey });

const MODEL_NAME = 'gemini-2.5-flash';

/**
 * Chat with the AI Tutor.
 * Uses a system instruction to act as a personalized teacher.
 */
export const chatWithTutor = async (history: Message[], userMessage: string): Promise<string> => {
  try {
    const chat = ai.chats.create({
      model: MODEL_NAME,
      config: {
        systemInstruction: `You are Lumina, a highly intelligent, patient, and personalized AI teacher. 
        Your goal is to explain concepts simply, clear doubts instantly, and make learning interesting using real-life examples.
        - Adapt to the student's level (assume K-12 unless specified).
        - If a student is weak, provide extra support and simpler breakdowns.
        - If a student is strong, offer advanced insights.
        - Use formatting (markdown) to make text readable.
        - Be encouraging and supportive.
        - VISUALIZATION REQUESTS: If the user asks to "see", "show", "visualize" or for a "3D model" of a physical concept (like a planet, atom, cell, organ, shape, etc.), explain it briefly, and then append this tag exactly at the end of your response: [[GENERATE_3D_MODEL: <Concept Name>]]. Example: [[GENERATE_3D_MODEL: DNA Double Helix]].`,
      },
      history: history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }],
      })),
    });

    const result = await chat.sendMessage({ message: userMessage });
    return result.text || "I'm sorry, I couldn't generate a response.";
  } catch (error) {
    console.error("Chat Error:", error);
    throw new Error("Failed to connect to AI Tutor.");
  }
};

/**
 * Generates a personalized study plan in JSON format.
 */
export const generateStudyPlan = async (
  grade: string,
  weakSubjects: string,
  goals: string
): Promise<StudyPlanData> => {
  try {
    const prompt = `Create a 3-day sample study plan for a Grade ${grade} student.
    Weak areas: ${weakSubjects}.
    Goals: ${goals}.
    
    Return the response strictly in JSON format matching the schema.`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            weeklySchedule: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  day: { type: Type.STRING },
                  sessions: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        time: { type: Type.STRING },
                        subject: { type: Type.STRING },
                        topic: { type: Type.STRING },
                        activity: { type: Type.STRING },
                      },
                    },
                  },
                },
              },
            },
            tips: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No data returned");
    return JSON.parse(text) as StudyPlanData;
  } catch (error) {
    console.error("Plan Gen Error:", error);
    throw new Error("Failed to generate study plan.");
  }
};

/**
 * Generates a quiz in JSON format.
 */
export const generateQuiz = async (topic: string, difficulty: string): Promise<QuizData> => {
  try {
    const prompt = `Create a 5-question multiple choice quiz about "${topic}". Difficulty: ${difficulty}.`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.INTEGER },
                  question: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  correctAnswerIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING },
                },
              },
            },
          },
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No data returned");
    return JSON.parse(text) as QuizData;
  } catch (error) {
    console.error("Quiz Gen Error:", error);
    throw new Error("Failed to generate quiz.");
  }
};

/**
 * Generates a summary report for parents.
 */
export const generateParentReport = async (stats: any): Promise<string> => {
  try {
    const prompt = `
      You are an intelligent educational assistant. Write a short, professional, yet encouraging weekly progress report for a parent based on the following student stats.
      
      Student Name: Alex
      Attendance: ${stats.attendance}% (Late twice this week)
      Weekly Subject Scores:
      - Math: ${stats.math}%
      - Science: ${stats.science}%
      - English: ${stats.english}%
      - History: ${stats.history}%
      
      Extracurricular Performance:
      - Sports (Athletics): ${stats.sports}% (Very active)
      - Cultural Activities (Drama/Music): ${stats.cultural}%
      
      Highlight the strengths (especially in extra-curriculars if high), mention the attendance pattern gently, and suggest one actionable improvement. Keep it under 100 words.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
    });

    return response.text || "Report generation failed.";
  } catch (error) {
    console.error("Report Gen Error:", error);
    throw new Error("Failed to generate report.");
  }
};

/**
 * Generates an email body for daily quiz results.
 */
export const generateDailyEmail = async (topic: string, score: number, total: number): Promise<string> => {
  try {
    const prompt = `
      Write a short, friendly notification email to a parent about their child's daily learning.
      Topic Learned: ${topic}
      Quiz Score: ${score}/${total}
      
      If the score is high, be very congratulatory. If low, be encouraging. 
      Briefly mention what is interesting about ${topic} in one sentence.
      Keep it under 50 words.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
    });

    return response.text || "Report generated.";
  } catch (error) {
    console.error("Email Gen Error:", error);
    return `Your child scored ${score}/${total} on today's ${topic} quiz.`;
  }
};

/**
 * Analyzes login credentials to fix typos or weak passwords.
 */
export const aiFixLogin = async (email: string): Promise<{ fixedEmail: string; suggestion: string; isFixed: boolean }> => {
  try {
    const prompt = `
      Analyze this email address: "${email}".
      1. Check for common typos (e.g., "gmal.com", "yaho.com", "outlok.com").
      2. If found, correct it.
      3. Return a JSON object with:
         - fixedEmail: the corrected email (or original if fine).
         - suggestion: A short 5-word message explaining the fix (e.g. "Fixed typo in 'gmail.com'").
         - isFixed: boolean (true if changed, false if not).
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            fixedEmail: { type: Type.STRING },
            suggestion: { type: Type.STRING },
            isFixed: { type: Type.BOOLEAN },
          },
        },
      },
    });

    const text = response.text;
    if (!text) return { fixedEmail: email, suggestion: "No fix needed", isFixed: false };
    return JSON.parse(text);
  } catch (error) {
    return { fixedEmail: email, suggestion: "AI unavailable", isFixed: false };
  }
};

/**
 * Generates a batch of bubble game data.
 */
export const generateBubbleLevel = async (subject: string): Promise<BubbleGameLevel> => {
  try {
    const prompt = `Generate a fast-paced "Bubble Pop" game level for a student about "${subject}".
    1. Create 5 short questions where the answer is very short (1-3 words or a number).
       Example for Math: Q="5+7", A="12". 
       Example for Science: Q="Symbol for Oxygen", A="O".
    2. Provide 15 "decoy" answers that look plausible for this subject but are wrong.
    
    Return strict JSON.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.INTEGER },
                  text: { type: Type.STRING },
                  answer: { type: Type.STRING }
                }
              }
            },
            decoys: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No data");
    return JSON.parse(text) as BubbleGameLevel;
  } catch (error) {
    throw new Error("Failed to generate game level");
  }
};

/**
 * Scans a topic and returns a detailed description plus visual categorization.
 */
export const scanTopic = async (topic: string): Promise<ScanResult> => {
  try {
    const prompt = `
    Analyze the educational topic: "${topic}".
    1. Provide a detailed, easy-to-understand description for a student.
    2. List 3 key bullet points (facts).
    3. CATEGORIZE the topic into exactly one of these visual types based on what would be best to show in a 3D hologram:
       - 'COSMOS' (Space, planets, stars, black holes)
       - 'ATOMIC' (Atoms, molecules, chemistry, quantum physics, electrons)
       - 'BIOLOGY' (Cells, DNA, animals, plants, human body)
       - 'GEOMETRY' (Math shapes, structures, buildings, crystals)
       - 'HISTORY' (General default, books, ancient artifacts, people)
    
    Return strictly JSON.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            description: { type: Type.STRING },
            keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
            visualType: { type: Type.STRING, enum: ['COSMOS', 'ATOMIC', 'BIOLOGY', 'GEOMETRY', 'HISTORY'] }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No data");
    return JSON.parse(text) as ScanResult;
  } catch (error) {
    throw new Error("Failed to scan topic");
  }
};

/**
 * Generates a single game question (Legacy - kept for backward compatibility if needed).
 */
export const generateGameQuestion = async (subject: string): Promise<GameQuestion> => {
  try {
    const prompt = `Generate a fun, trivia-style educational question for a student about "${subject}".
    It should be interesting and engaging.
    Include a "fact" that explains the answer in a fun way (Did you know...?).
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctIndex: { type: Type.INTEGER },
            fact: { type: Type.STRING }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No data");
    return JSON.parse(text) as GameQuestion;
  } catch (error) {
    throw new Error("Failed to generate game question");
  }
};