import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { AiTutor } from './components/AiTutor';
import { StudyPlanner } from './components/StudyPlanner';
import { QuizMode } from './components/QuizMode';
import { ParentConnect } from './components/ParentConnect';
import { ThreeDLearning } from './components/ThreeDLearning';
import { GameZone } from './components/GameZone';
import { AIScanner } from './components/AIScanner';
import { Login } from './components/Login';
import { AppView } from './types';
import { Menu, Search, Bell, ChevronDown, AlertCircle, Sparkles } from 'lucide-react';

// Error Boundary Component
class ErrorBoundary extends React.Component<{children: React.ReactNode}, {hasError: boolean, error: any}> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("Application Error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-[#02040a] p-4 text-center text-white">
           <div className="bg-white/5 backdrop-blur-xl p-8 rounded-2xl shadow-2xl max-w-lg w-full border border-red-500/30">
             <div className="w-16 h-16 bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4 border border-red-500/50">
               <AlertCircle className="w-8 h-8 text-red-500" />
             </div>
             <h1 className="text-2xl font-bold text-red-400 mb-2">System Critical Error</h1>
             <p className="text-gray-400 mb-6">The neural link encountered an unexpected interruption.</p>
             <div className="bg-black/50 p-4 rounded-lg text-left overflow-auto max-h-40 mb-6 border border-white/10">
                <code className="text-xs text-red-300 font-mono">
                  {this.state.error?.toString() || 'Unknown Error'}
                </code>
             </div>
             <button 
               onClick={() => window.location.reload()}
               className="w-full bg-red-600/80 hover:bg-red-500 text-white font-bold py-3 rounded-xl transition-all shadow-[0_0_20px_rgba(220,38,38,0.4)]"
             >
               Reboot System
             </button>
           </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function AppContent() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeQuizTopic, setActiveQuizTopic] = useState<string>('');

  if (!isAuthenticated) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  const handleStartQuizFrom3D = (topic: string) => {
    setActiveQuizTopic(topic);
    setCurrentView(AppView.QUIZ);
  };

  const getPageTitle = () => {
    switch (currentView) {
      case AppView.DASHBOARD: return 'Command Center';
      case AppView.TUTOR: return 'Lumina AI Tutor';
      case AppView.PLANNER: return 'Study Logistics';
      case AppView.QUIZ: return 'Neural Training';
      case AppView.PARENT_CONNECT: return 'Guardian Uplink';
      case AppView.THREE_D_LEARNING: return 'Holo-Lab';
      case AppView.GAME: return 'Simulation Zone';
      case AppView.AI_SCANNER: return 'Deep Scan';
      default: return 'Lumina OS';
    }
  };

  const renderContent = () => {
    switch (currentView) {
      case AppView.DASHBOARD: return <Dashboard />;
      case AppView.TUTOR: return <AiTutor />;
      case AppView.PLANNER: return <StudyPlanner />;
      case AppView.QUIZ: return <QuizMode initialTopic={activeQuizTopic} />;
      case AppView.PARENT_CONNECT: return <ParentConnect />;
      case AppView.THREE_D_LEARNING: return <ThreeDLearning onStartQuiz={handleStartQuizFrom3D} />;
      case AppView.GAME: return <GameZone />;
      case AppView.AI_SCANNER: return <AIScanner />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#02040a] flex font-sans text-gray-100 animate-fade-in selection:bg-cyan-500/30">
      
      {/* Dynamic Background Mesh */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-indigo-900/10 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-cyan-900/10 rounded-full blur-[120px]"></div>
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-5"></div>
      </div>

      {/* Sidebar Navigation */}
      <Sidebar currentView={currentView} onChangeView={(view) => {
        setCurrentView(view);
        if (view !== AppView.QUIZ) setActiveQuizTopic(''); 
      }} />
      
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm md:hidden" onClick={() => setIsMobileMenuOpen(false)}>
           <div className="w-72 h-full bg-[#0B0F19] shadow-2xl border-r border-white/10 animate-fade-in-left" onClick={e => e.stopPropagation()}>
             <Sidebar currentView={currentView} onChangeView={(view) => {
               setCurrentView(view);
               setIsMobileMenuOpen(false);
             }} />
           </div>
        </div>
      )}

      {/* Main Layout */}
      <div className="flex-1 md:ml-72 flex flex-col min-w-0 transition-all duration-300 relative z-10">
        
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-[#02040a]/80 backdrop-blur-xl border-b border-white/5 px-6 py-4 flex items-center justify-between">
           <div className="flex items-center gap-4">
             <button onClick={() => setIsMobileMenuOpen(true)} className="md:hidden p-2 hover:bg-white/10 rounded-lg text-gray-300">
                <Menu className="w-5 h-5" />
             </button>
             <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400 hidden md:flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                {getPageTitle()}
             </h1>
           </div>

           <div className="flex items-center gap-4 md:gap-6">
              {/* Search Bar (Visual) */}
              <div className="hidden md:flex items-center bg-white/5 border border-white/10 rounded-full px-4 py-2 w-64 focus-within:ring-2 focus-within:ring-cyan-500/50 transition-all group">
                 <Search className="w-4 h-4 text-gray-500 group-focus-within:text-cyan-400 transition-colors" />
                 <input 
                   type="text" 
                   placeholder="Search neural database..." 
                   className="bg-transparent border-none outline-none text-sm ml-2 w-full placeholder-gray-600 text-gray-200"
                 />
              </div>

              {/* Notification & Profile */}
              <div className="flex items-center gap-3 border-l border-white/10 pl-4 md:pl-6">
                 <button className="relative p-2 hover:bg-white/5 rounded-full text-gray-400 hover:text-white transition-colors">
                    <Bell className="w-5 h-5" />
                    <span className="absolute top-1.5 right-2 w-2 h-2 bg-red-500 rounded-full shadow-[0_0_10px_red]"></span>
                 </button>
                 
                 <div className="flex items-center gap-3 cursor-pointer hover:bg-white/5 p-1.5 rounded-full pr-3 transition-colors border border-transparent hover:border-white/10">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white font-bold text-sm ring-2 ring-black shadow-lg">
                       AJ
                    </div>
                    <div className="hidden md:block">
                       <p className="text-sm font-semibold text-gray-200 leading-none">Alex J.</p>
                       <p className="text-[10px] text-cyan-400 font-medium mt-0.5 font-mono">Lvl 10 • Cadet</p>
                    </div>
                    <ChevronDown className="w-4 h-4 text-gray-500 hidden md:block" />
                 </div>
              </div>
           </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 p-4 md:p-8 overflow-y-auto scrollbar-hide">
           <div className="max-w-7xl mx-auto h-full">
              {/* Mobile Title if needed */}
              <div className="md:hidden mb-6 flex items-center justify-between">
                <h2 className="text-2xl font-bold text-white">{getPageTitle()}</h2>
              </div>
              
              {renderContent()}
           </div>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppContent />
    </ErrorBoundary>
  );
}