import React, { useState, useEffect, useRef } from 'react';
import { Box, Play, Info, ArrowLeft, Cuboid, Dna, Globe, Cpu, Bot, Send, User, Loader2, Sparkles, Scan, RotateCw, Microscope, Atom, ChevronRight } from 'lucide-react';
import { AppView, Message } from '../types';
import { chatWithTutor } from '../services/gemini';
import ReactMarkdown from 'react-markdown';

interface ThreeDLearningProps {
  onStartQuiz: (topic: string) => void;
}

// Enhanced Model Data with visual props
const models = [
  { 
    id: 'solar-system', 
    name: 'Solar System', 
    icon: Globe, 
    color: 'text-blue-400', 
    glow: 'shadow-blue-500',
    description: "Orbital mechanics, planetary composition, and gravity wells." 
  },
  { 
    id: 'dna', 
    name: 'DNA Helix', 
    icon: Dna, 
    color: 'text-pink-400', 
    glow: 'shadow-pink-500',
    description: "Genetic encoding, nucleotide base pairing, and replication." 
  },
  { 
    id: 'cpu', 
    name: 'Quantum CPU', 
    icon: Cpu, 
    color: 'text-purple-400', 
    glow: 'shadow-purple-500',
    description: "Micro-architecture, logic gates, and processing cores." 
  },
  { 
    id: 'atom', 
    name: 'Atomic Structure', 
    icon: Atom, 
    color: 'text-cyan-400', 
    glow: 'shadow-cyan-500',
    description: "Electron shells, valence electrons, and nucleus binding energy." 
  },
];

export const ThreeDLearning: React.FC<ThreeDLearningProps> = ({ onStartQuiz }) => {
  const [activeModel, setActiveModel] = useState<typeof models[0] | null>(null);
  const [isRotating, setIsRotating] = useState(true);
  
  // Chat State
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize chat when model changes
  useEffect(() => {
    if (activeModel) {
      setMessages([{
        id: 'init',
        role: 'model',
        text: `**System Online.** \n\nI have loaded the **${activeModel.name}** simulation. Select specific components to analyze or ask me about its function.`,
        timestamp: new Date()
      }]);
    }
  }, [activeModel]);

  // Auto-scroll chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || isAiLoading || !activeModel) return;

    const userText = input;
    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: userText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    setInput('');
    setIsAiLoading(true);

    try {
      // Contextual prompt for the AI
      const contextMessage: Message = {
        id: 'system-context',
        role: 'user',
        text: `[SYSTEM CONTEXT: The user is examining a holographic model of "${activeModel.name}". Keep responses technical yet accessible, acting as a lab assistant. Focus on visual descriptions.]`,
        timestamp: new Date()
      };
      
      const historyForApi = [contextMessage, ...messages.slice(-6)];
      const response = await chatWithTutor(historyForApi, userText);
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
       const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: "Connection instability detected. Unable to process query.",
        timestamp: new Date(),
        isError: true
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="h-full relative overflow-hidden bg-[#02040a] text-white font-sans animate-fade-in flex flex-col rounded-2xl border border-gray-800">
       {/* Background Grid - Global */}
       <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px] pointer-events-none"></div>
       <div className="absolute inset-0 bg-radial-gradient from-indigo-900/20 to-black pointer-events-none"></div>
       
       {!activeModel ? (
          // SELECTION VIEW (HOLO-DECK)
          <div className="relative z-10 flex flex-col items-center justify-center h-full p-8 overflow-y-auto">
             <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-900/30 border border-indigo-500/30 text-indigo-300 text-xs font-bold uppercase tracking-widest mb-4">
                   <Microscope className="w-4 h-4" /> Virtual Lab v2.0
                </div>
                <h1 className="text-4xl md:text-5xl font-black bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-500 mb-4 tracking-tight">
                   Select Specimen
                </h1>
                <p className="text-gray-400 max-w-md mx-auto">
                   Choose a holographic model to initialize the containment field.
                </p>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 w-full max-w-6xl">
                {models.map(model => (
                   <button 
                     key={model.id}
                     onClick={() => setActiveModel(model)}
                     className="group relative h-80 rounded-3xl bg-gray-900/40 border border-white/10 hover:border-indigo-500/50 transition-all duration-300 overflow-hidden text-left hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(79,70,229,0.2)]"
                   >
                      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/80 z-10"></div>
                      
                      {/* Scanning Line Effect */}
                      <div className="absolute top-0 left-0 w-full h-[2px] bg-indigo-500/50 shadow-[0_0_10px_indigo] z-20 opacity-0 group-hover:opacity-100 animate-scan"></div>
                      
                      {/* Preview Hologram */}
                      <div className="absolute inset-0 flex items-center justify-center opacity-50 group-hover:opacity-100 transition-opacity duration-500 transform group-hover:scale-110">
                         <model.icon className={`w-32 h-32 ${model.color} drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]`} strokeWidth={1} />
                      </div>

                      <div className="absolute bottom-0 left-0 w-full p-6 z-20">
                         <h3 className="text-2xl font-bold text-white mb-1 group-hover:text-indigo-300 transition-colors">{model.name}</h3>
                         <p className="text-sm text-gray-400 line-clamp-2">{model.description}</p>
                         <div className="mt-4 flex items-center gap-2 text-xs font-bold text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                            INITIALIZE <ChevronRight className="w-3 h-3" />
                         </div>
                      </div>
                   </button>
                ))}
             </div>
          </div>
       ) : (
          // LAB VIEW (IMMERSIVE MODE)
          <div className="flex flex-col md:flex-row h-full relative z-10">
             {/* Left: 3D Stage */}
             <div className="flex-1 relative flex flex-col min-h-[50vh]">
                {/* Header */}
                <div className="absolute top-0 left-0 w-full p-6 flex items-start justify-between z-20 pointer-events-none">
                   <button 
                     onClick={() => setActiveModel(null)}
                     className="pointer-events-auto flex items-center gap-2 px-4 py-2 rounded-xl bg-black/40 backdrop-blur border border-white/10 text-gray-300 hover:text-white hover:bg-white/10 transition-colors"
                   >
                      <ArrowLeft className="w-4 h-4" /> Back
                   </button>
                   
                   <div className="text-right pointer-events-auto">
                      <h2 className="text-3xl font-black text-white tracking-tight">{activeModel.name}</h2>
                      <div className="flex items-center justify-end gap-2 text-[10px] font-mono text-indigo-400 mt-1 uppercase tracking-widest">
                         <Scan className="w-3 h-3 animate-pulse" /> Live Simulation
                      </div>
                   </div>
                </div>

                {/* 3D Viewport */}
                <div className="flex-1 flex items-center justify-center relative perspective-container overflow-hidden">
                   {/* Floor Grid */}
                   <div className="absolute bottom-0 w-[200%] h-1/2 bg-[linear-gradient(transparent,rgba(79,70,229,0.1))] transform -rotate-x-60 translate-y-12 blur-sm pointer-events-none"></div>

                   {/* The Object */}
                   <div className={`relative w-64 h-64 transform-style-3d ${isRotating ? 'animate-spin-slow' : ''}`}>
                      {/* Wireframe Sphere */}
                      <div className="absolute inset-0 border border-indigo-500/20 rounded-full"></div>
                      <div className="absolute inset-0 border border-indigo-500/20 rounded-full transform rotate-y-60"></div>
                      <div className="absolute inset-0 border border-indigo-500/20 rounded-full transform rotate-x-60"></div>
                      
                      {/* Core Icon */}
                      <div className="absolute inset-0 flex items-center justify-center">
                         <activeModel.icon className={`w-32 h-32 ${activeModel.color} drop-shadow-[0_0_50px_rgba(255,255,255,0.2)]`} strokeWidth={0.5} />
                      </div>
                      
                      {/* Floating Particles */}
                      <div className="absolute top-0 left-1/2 w-2 h-2 bg-white rounded-full shadow-[0_0_10px_white]"></div>
                      <div className="absolute bottom-10 right-0 w-1 h-1 bg-indigo-400 rounded-full"></div>
                   </div>
                </div>

                {/* Controls Bar */}
                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-black/60 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10 z-20 shadow-2xl">
                   <button 
                     onClick={() => setIsRotating(!isRotating)}
                     className={`p-3 rounded-xl transition-all ${isRotating ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
                     title="Toggle Rotation"
                   >
                      <RotateCw className={`w-5 h-5 ${isRotating ? 'animate-spin-slow' : ''}`} />
                   </button>
                   <div className="h-8 w-[1px] bg-white/10"></div>
                   <button 
                     onClick={() => onStartQuiz(activeModel.name)}
                     className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-lg transition-colors flex items-center gap-2"
                   >
                      <Sparkles className="w-4 h-4 text-yellow-400" /> Take Quiz
                   </button>
                </div>
             </div>

             {/* Right: Analysis Panel (Chat) */}
             <div className="w-full md:w-96 bg-black/40 backdrop-blur-xl border-l border-white/10 flex flex-col shadow-2xl">
                <div className="p-4 border-b border-white/5 bg-white/5 flex items-center justify-between">
                   <h3 className="text-xs font-bold text-indigo-300 uppercase tracking-widest flex items-center gap-2">
                      <Bot className="w-4 h-4" /> Diagnostic Feed
                   </h3>
                   <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div>
                      <div className="w-1.5 h-1.5 rounded-full bg-yellow-500"></div>
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                   </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
                   {messages.map(msg => (
                      <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                         <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border border-white/10 ${msg.role === 'user' ? 'bg-indigo-600' : 'bg-gray-800'}`}>
                            {msg.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-cyan-400" />}
                         </div>
                         <div className={`p-3 rounded-lg text-sm leading-relaxed ${msg.role === 'user' ? 'bg-indigo-900/50 text-indigo-100 border border-indigo-500/30' : 'bg-gray-800/50 text-gray-300 border border-gray-700'}`}>
                            {msg.role === 'model' ? (
                               <div className="prose prose-sm prose-invert max-w-none prose-p:my-1 prose-ul:my-1">
                                  <ReactMarkdown>{msg.text}</ReactMarkdown>
                               </div>
                            ) : msg.text}
                         </div>
                      </div>
                   ))}
                   {isAiLoading && (
                      <div className="flex gap-3">
                         <div className="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center shrink-0 border border-white/10">
                            <Bot className="w-4 h-4 text-cyan-400" />
                         </div>
                         <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700 flex items-center gap-2">
                            <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                            <span className="text-xs text-gray-400 font-mono">PROCESSING...</span>
                         </div>
                      </div>
                   )}
                   <div ref={messagesEndRef} />
                </div>

                <div className="p-4 border-t border-white/10 bg-white/5">
                   <div className="relative group">
                      <div className="absolute -inset-0.5 bg-gradient-to-r from-indigo-500 to-cyan-500 rounded-xl opacity-20 group-focus-within:opacity-50 transition duration-500 blur"></div>
                      <div className="relative flex items-center bg-black rounded-xl border border-white/10">
                         <input 
                           value={input}
                           onChange={(e) => setInput(e.target.value)}
                           onKeyDown={handleKeyDown}
                           placeholder="Type a query..."
                           className="w-full bg-transparent py-3 pl-4 pr-12 text-sm text-white placeholder-gray-600 focus:outline-none"
                           disabled={isAiLoading}
                         />
                         <button 
                           onClick={handleSendMessage}
                           disabled={!input.trim() || isAiLoading}
                           className="absolute right-2 p-1.5 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-white transition-colors disabled:opacity-50 disabled:bg-gray-800"
                         >
                            <Send className="w-3 h-3" />
                         </button>
                      </div>
                   </div>
                </div>
             </div>
          </div>
       )}
       
       <style>{`
         .perspective-container { perspective: 1000px; }
         .transform-style-3d { transform-style: preserve-3d; }
         .rotate-x-60 { transform: rotateX(60deg); }
         .rotate-y-60 { transform: rotateY(60deg); }
         @keyframes scan {
           0% { top: 0; opacity: 0; }
           50% { opacity: 1; }
           100% { top: 100%; opacity: 0; }
         }
         .animate-scan { animation: scan 2s linear infinite; }
         @keyframes spin-slow {
           from { transform: rotateY(0deg); }
           to { transform: rotateY(360deg); }
         }
         .animate-spin-slow { animation: spin-slow 20s linear infinite; }
       `}</style>
    </div>
  );
};