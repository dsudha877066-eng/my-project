import React, { useState } from 'react';
import { Cpu, Wifi, Shield, ScanLine, ArrowRight, CreditCard, Lock, Sparkles, AlertCircle, Terminal } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [studentId, setStudentId] = useState('');
  const [pin, setPin] = useState('');
  const [status, setStatus] = useState<'IDLE' | 'SCANNING' | 'SUCCESS'>('IDLE');
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!studentId || !pin) {
      setError("Please insert valid credentials.");
      return;
    }

    setError(null);
    setStatus('SCANNING');

    // Simulate Scanning Delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Simple mock validation (Accepts anything length > 3 for demo)
    if (studentId.length > 3 && pin.length > 3) {
      setStatus('SUCCESS');
      await new Promise(resolve => setTimeout(resolve, 800));
      onLogin();
    } else {
      setStatus('IDLE');
      setError("ID verification failed. Access denied.");
    }
  };

  const loadDemo = () => {
    setStudentId('LUM-8842');
    setPin('992024');
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#050914] flex items-center justify-center relative overflow-hidden font-sans selection:bg-cyan-500/30">
      
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:60px_60px] pointer-events-none"></div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-[128px]"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-600/20 rounded-full blur-[128px]"></div>

      <style>{`
        .perspective-container { perspective: 1200px; }
        .transform-3d { transform-style: preserve-3d; transition: transform 0.2s ease-out; }
        .backface-hidden { backface-visibility: hidden; }
        
        @keyframes float-card {
           0%, 100% { transform: translateY(0px) rotateX(0deg); }
           50% { transform: translateY(-15px) rotateX(2deg); }
        }
        @keyframes hologram-scan {
           0% { top: 0; opacity: 0; }
           20% { opacity: 1; }
           80% { opacity: 1; }
           100% { top: 100%; opacity: 0; }
        }
        .animate-float-card { animation: float-card 6s ease-in-out infinite; }
        .animate-scan-line { animation: hologram-scan 2s linear infinite; }
      `}</style>

      {/* 3D Container */}
      <div className="perspective-container relative z-10 p-4">
        
        {/* Floating Card Wrapper */}
        <div className={`relative w-[380px] md:w-[420px] transform-3d animate-float-card group`}>
          
          {/* THE CARD */}
          <div className="bg-[#0f1219]/80 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-[0_0_50px_rgba(0,0,0,0.5)] relative overflow-hidden transition-all duration-300 group-hover:shadow-[0_0_80px_rgba(79,70,229,0.3)] group-hover:border-indigo-500/30">
             
             {/* Holographic Sheen */}
             <div className="absolute inset-0 bg-gradient-to-tr from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
             
             {/* Header */}
             <div className="flex justify-between items-start mb-8 relative z-10">
                <div className="flex items-center gap-3">
                   <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg border border-white/10">
                      <Shield className="w-6 h-6 text-white" />
                   </div>
                   <div>
                      <h1 className="text-xl font-black text-white tracking-tight">LUMINA<span className="text-cyan-400">.ID</span></h1>
                      <p className="text-[10px] text-gray-400 font-mono tracking-widest uppercase">Student Access Card</p>
                   </div>
                </div>
                <div className="flex flex-col items-end">
                   <Wifi className="w-5 h-5 text-emerald-500 drop-shadow-[0_0_8px_rgba(16,185,129,0.6)]" />
                   <span className="text-[8px] text-emerald-400 font-bold mt-1 tracking-wider">ONLINE</span>
                </div>
             </div>

             {/* Chip & Visuals */}
             <div className="flex justify-between items-center mb-8 relative z-10">
                <div className="w-14 h-10 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-lg border border-yellow-300/30 flex items-center justify-center relative overflow-hidden shadow-inner">
                   <Cpu className="w-8 h-8 text-yellow-900/40 relative z-10" />
                   <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.3)_50%,transparent_75%)] bg-[length:250%_250%] animate-pulse"></div>
                </div>
                <div className="text-right">
                   <p className="text-[10px] text-indigo-300 font-mono mb-1">SECURE GATEWAY</p>
                   <div className="flex gap-1 justify-end">
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse"></div>
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse delay-75"></div>
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse delay-150"></div>
                   </div>
                </div>
             </div>

             {/* Login Form */}
             <form onSubmit={handleLogin} className="space-y-5 relative z-10">
                <div className="space-y-1">
                   <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Student Identification</label>
                   <div className="relative group/input">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                         <CreditCard className="h-4 w-4 text-indigo-400 group-focus-within/input:text-white transition-colors" />
                      </div>
                      <input
                        type="text"
                        value={studentId}
                        onChange={(e) => setStudentId(e.target.value.toUpperCase())}
                        placeholder="ID-NUMBER"
                        className="block w-full pl-10 pr-3 py-3.5 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50 transition-all font-mono tracking-widest text-sm"
                        disabled={status !== 'IDLE'}
                      />
                   </div>
                </div>

                <div className="space-y-1">
                   <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Access PIN</label>
                   <div className="relative group/input">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                         <Lock className="h-4 w-4 text-indigo-400 group-focus-within/input:text-white transition-colors" />
                      </div>
                      <input
                        type="password"
                        value={pin}
                        onChange={(e) => setPin(e.target.value)}
                        placeholder="••••"
                        className="block w-full pl-10 pr-3 py-3.5 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50 transition-all font-mono tracking-widest text-sm"
                        disabled={status !== 'IDLE'}
                        maxLength={6}
                      />
                   </div>
                </div>

                {error && (
                   <div className="flex items-center gap-2 text-red-400 text-xs bg-red-900/10 p-2 rounded-lg border border-red-500/20 animate-fade-in">
                      <AlertCircle className="w-3 h-3" /> {error}
                   </div>
                )}

                <button
                  type="submit"
                  disabled={status !== 'IDLE'}
                  className="w-full relative overflow-hidden group/btn bg-white text-black font-black py-4 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-80 disabled:hover:scale-100 shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.3)]"
                >
                   <div className="absolute inset-0 bg-gradient-to-r from-transparent via-gray-200 to-transparent translate-x-[-100%] group-hover/btn:translate-x-[100%] transition-transform duration-700"></div>
                   
                   <span className="relative flex items-center justify-center gap-2">
                      {status === 'IDLE' && (
                         <>INITIALIZE SESSION <ArrowRight className="w-4 h-4" /></>
                      )}
                      {status === 'SCANNING' && (
                         <>
                            <ScanLine className="w-4 h-4 animate-pulse" /> VERIFYING BIOMETRICS...
                         </>
                      )}
                      {status === 'SUCCESS' && (
                         <>
                            <Sparkles className="w-4 h-4 text-indigo-600" /> ACCESS GRANTED
                         </>
                      )}
                   </span>
                </button>
             </form>
             
             {/* Scanning Overlay Effect */}
             {status === 'SCANNING' && (
                <div className="absolute inset-0 z-20 pointer-events-none">
                   <div className="absolute left-0 w-full h-1 bg-cyan-400 shadow-[0_0_20px_cyan] animate-scan-line"></div>
                   <div className="absolute inset-0 bg-cyan-500/5"></div>
                </div>
             )}
          </div>
          
          {/* Card Depth Effect (Bottom Shadow) */}
          <div className="absolute -bottom-10 left-10 right-10 h-4 bg-black/50 blur-xl rounded-full transform scale-x-90 animate-pulse"></div>
          
          {/* Demo Button */}
          {status === 'IDLE' && (
            <div className="mt-8 text-center animate-fade-in">
              <button 
                onClick={loadDemo}
                className="text-xs font-mono text-gray-500 hover:text-cyan-400 transition-colors flex items-center justify-center gap-2 mx-auto"
              >
                <Terminal className="w-3 h-3" />
                LOAD_DEMO_CREDENTIALS
              </button>
            </div>
          )}

        </div>
      </div>

      <div className="absolute bottom-6 text-center">
         <p className="text-[10px] text-gray-600 font-mono">
            LUMINA ACADEMY OS v4.2.0 <br /> 
            SECURE CONNECTION ESTABLISHED
         </p>
      </div>
    </div>
  );
};