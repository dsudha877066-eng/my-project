import React, { useState } from 'react';
import { Calendar, CheckCircle, Clock, BookOpen, Loader2, Target, Hourglass, Sparkles, ChevronRight, Brain } from 'lucide-react';
import { generateStudyPlan } from '../services/gemini';
import { StudyPlanData } from '../types';

export const StudyPlanner: React.FC = () => {
  const [grade, setGrade] = useState('10');
  const [weakSubjects, setWeakSubjects] = useState('');
  const [goals, setGoals] = useState('');
  const [plan, setPlan] = useState<StudyPlanData | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setPlan(null);
    try {
      const data = await generateStudyPlan(grade, weakSubjects, goals);
      setPlan(data);
    } catch (err) {
      alert("Failed to generate plan. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full animate-fade-in pb-10">
      <style>{`
        .perspective-container { perspective: 1000px; }
        .transform-style-3d { transform-style: preserve-3d; }
        
        @keyframes float-book {
          0%, 100% { transform: translateY(0px) rotateX(10deg) rotateY(-10deg); }
          50% { transform: translateY(-20px) rotateX(5deg) rotateY(10deg); }
        }
        
        @keyframes orbit-icon {
          0% { transform: rotate(0deg) translateX(80px) rotate(0deg); }
          100% { transform: rotate(360deg) translateX(80px) rotate(-360deg); }
        }

        .animate-float-book { animation: float-book 6s ease-in-out infinite; }
        .animate-orbit-icon { animation: orbit-icon 8s linear infinite; }
      `}</style>

      {/* Input Form Panel */}
      <div className="lg:col-span-4 flex flex-col">
        <div className="bg-[#0B0F19] p-8 rounded-3xl shadow-2xl border border-white/10 relative overflow-hidden flex-1 flex flex-col">
          {/* Background FX */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[80px] rounded-full pointer-events-none"></div>
          
          <div className="flex items-center gap-3 mb-8 relative z-10">
            <div className="p-3 bg-indigo-500/10 rounded-xl border border-indigo-500/20 shadow-[0_0_15px_rgba(99,102,241,0.1)]">
              <Calendar className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-tight">Strategy Module</h2>
              <p className="text-xs text-gray-500 font-mono uppercase tracking-wider">Configure Parameters</p>
            </div>
          </div>
          
          <form onSubmit={handleGenerate} className="space-y-6 flex-1 relative z-10">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Grade Level</label>
              <div className="relative group">
                 <select 
                  value={grade} 
                  onChange={(e) => setGrade(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all appearance-none cursor-pointer hover:bg-white/5"
                >
                  {[6, 7, 8, 9, 10, 11, 12].map(g => (
                    <option key={g} value={g} className="bg-gray-900 text-white">Grade {g}</option>
                  ))}
                </select>
                <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
                  <ChevronRight className="w-4 h-4 text-gray-500 rotate-90" />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Focus Areas (Weakness)</label>
              <input 
                type="text" 
                value={weakSubjects}
                onChange={(e) => setWeakSubjects(e.target.value)}
                placeholder="e.g. Thermodynamics, Calculus"
                className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all placeholder-gray-600"
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Objective</label>
              <textarea 
                value={goals}
                onChange={(e) => setGoals(e.target.value)}
                placeholder="e.g. Master core concepts before finals..."
                className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none h-32 resize-none transition-all placeholder-gray-600 leading-relaxed"
                required
              />
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-gradient-to-r from-indigo-600 to-cyan-600 text-white font-black py-4 rounded-xl hover:shadow-[0_0_20px_rgba(99,102,241,0.4)] transition-all active:scale-[0.98] flex items-center justify-center gap-3 mt-4 disabled:opacity-50 disabled:cursor-not-allowed group"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  PROCESSING...
                </>
              ) : (
                <>
                   <Brain className="w-5 h-5 group-hover:animate-pulse" />
                   GENERATE SCHEDULE
                </>
              )}
            </button>
          </form>

          <div className="mt-8 p-4 bg-indigo-900/10 rounded-xl text-xs text-indigo-300 border border-indigo-500/20 flex items-start gap-3">
             <Target className="w-4 h-4 shrink-0 mt-0.5 text-indigo-400" />
             <p className="leading-relaxed opacity-80">
               <strong className="text-indigo-200">AI Optimization:</strong> The system will analyze your inputs to construct a high-efficiency learning path.
             </p>
          </div>
        </div>
      </div>

      {/* Output Display Panel */}
      <div className="lg:col-span-8 flex flex-col h-full min-h-[500px]">
        {plan ? (
          <div className="bg-[#0B0F19]/80 backdrop-blur-xl p-8 rounded-3xl shadow-2xl border border-white/10 h-full animate-fade-in-up flex flex-col relative overflow-hidden">
             {/* Decorative Grid */}
             <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none"></div>

             <div className="flex items-center justify-between mb-8 relative z-10">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-900/20">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-white">Operational Schedule</h2>
                    <p className="text-xs text-green-400 font-mono uppercase">Status: Optimized</p>
                  </div>
                </div>
                <div className="hidden sm:flex px-4 py-2 bg-white/5 text-gray-300 rounded-full text-xs font-bold border border-white/10 items-center gap-2">
                   <Sparkles className="w-3 h-3 text-yellow-400" /> AI Generated
                </div>
             </div>
             
             {/* Tips Section */}
             {plan.tips && plan.tips.length > 0 && (
               <div className="mb-8 flex flex-wrap gap-3 relative z-10">
                 {plan.tips.map((tip, idx) => (
                   <span key={idx} className="bg-indigo-500/10 text-indigo-200 px-4 py-2 rounded-lg text-xs font-bold border border-indigo-500/20 flex items-center gap-2 shadow-sm hover:bg-indigo-500/20 transition-colors cursor-default">
                     <Sparkles className="w-3 h-3 text-indigo-400" /> {tip}
                   </span>
                 ))}
               </div>
             )}

             <div className="space-y-6 overflow-y-auto scrollbar-hide flex-1 relative z-10 pr-2">
               {plan.weeklySchedule.map((day, dayIdx) => (
                 <div key={dayIdx} className="bg-black/20 border border-white/5 rounded-2xl overflow-hidden hover:border-indigo-500/30 transition-all group">
                   {/* Day Header */}
                   <div className="px-6 py-4 border-b border-white/5 flex justify-between items-center bg-white/5">
                     <span className="font-bold text-lg text-white tracking-wide">{day.day}</span>
                     <span className="text-[10px] font-bold text-gray-400 bg-black/40 px-3 py-1 rounded-full border border-white/5">{day.sessions.length} MODULES</span>
                   </div>
                   
                   {/* Sessions */}
                   <div className="divide-y divide-white/5">
                     {day.sessions.map((session, sIdx) => (
                       <div key={sIdx} className="p-5 hover:bg-white/5 transition-colors flex flex-col md:flex-row md:items-center gap-6">
                         
                         {/* Time Pill */}
                         <div className="flex items-center gap-2 min-w-[140px]">
                           <div className="p-2 bg-gray-800 rounded-lg text-gray-400">
                             <Clock className="w-4 h-4" />
                           </div>
                           <span className="text-sm font-mono text-cyan-300 font-bold">{session.time}</span>
                         </div>
                         
                         <div className="flex-1">
                           <div className="flex flex-wrap items-center gap-3 mb-2">
                             <span className="px-2 py-1 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 uppercase tracking-widest border border-indigo-500/30 shadow-[0_0_10px_rgba(99,102,241,0.1)]">
                               {session.subject}
                             </span>
                             <span className="font-bold text-gray-200 text-sm">{session.topic}</span>
                           </div>
                           <p className="text-sm text-gray-500 flex items-start gap-2 leading-relaxed">
                             <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5 shrink-0 shadow-[0_0_5px_lime]"></div>
                             {session.activity}
                           </p>
                         </div>
                       </div>
                     ))}
                   </div>
                 </div>
               ))}
             </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center bg-[#0B0F19] rounded-3xl border border-dashed border-gray-800 p-12 perspective-container relative overflow-hidden group">
            
            {/* Ambient Background */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.1),transparent_70%)] opacity-50 group-hover:opacity-100 transition-opacity duration-1000"></div>

            {/* 3D Animation Object */}
            <div className="relative w-64 h-64 transform-style-3d animate-float-book mb-12 flex items-center justify-center">
               
               {/* Glowing Halo */}
               <div className="absolute inset-0 bg-indigo-600/30 blur-[60px] rounded-full transform scale-75 animate-pulse"></div>

               {/* Central Object (Futuristic Tome) */}
               <div className="relative w-36 h-48 bg-gray-900 rounded-xl shadow-2xl transform-style-3d flex flex-col items-center justify-center border border-white/10 z-10 group-hover:shadow-[0_0_50px_rgba(99,102,241,0.3)] transition-shadow">
                  {/* Book Cover Design */}
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 to-black opacity-90 rounded-xl"></div>
                  <div className="absolute inset-0 border-[2px] border-indigo-500/50 rounded-xl m-2"></div>
                  
                  {/* Spine */}
                  <div className="absolute top-0 bottom-0 left-0 w-4 bg-gray-800 rounded-l-xl border-r border-white/5"></div>
                  
                  {/* Holographic Symbol */}
                  <div className="relative z-20 w-16 h-16 rounded-full border border-cyan-500/50 flex items-center justify-center shadow-[0_0_15px_cyan] bg-black/50 backdrop-blur-sm">
                    <Calendar className="text-cyan-400 w-8 h-8" />
                  </div>
                  
                  {/* Fake 3D Thickness */}
                  <div className="absolute top-1 bottom-1 -right-6 w-6 bg-gray-800 rounded-r-md transform skew-y-12 origin-left shadow-lg border-l border-white/10 flex flex-col justify-evenly py-4">
                     {/* Pages lines */}
                     {[...Array(5)].map((_,i) => <div key={i} className="w-full h-[1px] bg-white/20"></div>)}
                  </div>
               </div>
               
               {/* Orbiting Elements */}
               <div className="absolute inset-0 z-20">
                  {/* Item 1: Clock */}
                  <div className="absolute top-1/2 left-1/2 w-12 h-12 bg-black border border-orange-500/50 shadow-[0_0_20px_orange] rounded-full flex items-center justify-center animate-orbit-icon">
                     <Clock className="w-5 h-5 text-orange-400" />
                  </div>
                  
                  {/* Item 2: Target (Offset delay) */}
                  <div className="absolute top-1/2 left-1/2 w-12 h-12 bg-black border border-emerald-500/50 shadow-[0_0_20px_emerald] rounded-full flex items-center justify-center animate-orbit-icon" style={{ animationDelay: '-4s' }}>
                     <Target className="w-5 h-5 text-emerald-400" />
                  </div>
               </div>

               {/* Floor Shadow */}
               <div className="absolute -bottom-24 left-1/2 w-48 h-12 bg-indigo-500/20 blur-xl rounded-full transform -translate-x-1/2 scale-x-150"></div>
            </div>

            <div className="text-center relative z-10 max-w-md">
               <h3 className="text-3xl font-black text-white mb-4 tracking-tight">
                 Awaiting <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Parameters</span>
               </h3>
               <p className="text-gray-400 leading-relaxed">
                 Enter your academic focus areas. The AI will construct a hyper-optimized schedule tailored to your learning velocity.
               </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};