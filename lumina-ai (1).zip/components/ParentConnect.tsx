import React, { useState, useRef, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';
import { UserCheck, AlertCircle, Clock, FileText, Sparkles, Loader2, Music, Trophy, Shield, ScanFace, Activity, Share2, Link, Mail, Check, X, Wifi } from 'lucide-react';
import { generateParentReport } from '../services/gemini';

// --- Mock Data ---
const weeklyPerformanceData = [
  { day: 'Mon', Math: 65, Science: 75, English: 80, Sports: 85, Cultural: 70 },
  { day: 'Tue', Math: 68, Science: 78, English: 82, Sports: 88, Cultural: 75 },
  { day: 'Wed', Math: 75, Science: 72, English: 85, Sports: 90, Cultural: 80 },
  { day: 'Thu', Math: 72, Science: 82, English: 84, Sports: 85, Cultural: 85 },
  { day: 'Fri', Math: 80, Science: 88, English: 86, Sports: 92, Cultural: 88 },
];

const attendanceLog = [
  { date: 'Today', time: '08:15 AM', status: 'Present', method: 'Biometric Verified' },
  { date: 'Yesterday', time: '08:20 AM', status: 'Present', method: 'Biometric Verified' },
  { date: 'Wed, Oct 24', time: '08:45 AM', status: 'Late', method: 'Manual Override' },
  { date: 'Tue, Oct 23', time: '08:10 AM', status: 'Present', method: 'Biometric Verified' },
];

// --- 3D Network Visualizer Component ---
const NeuralLinkVisualizer = ({ active }: { active: boolean }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let nodes: any[] = [];
    let animationFrameId: number;

    const resize = () => {
      canvas.width = canvas.clientWidth;
      canvas.height = canvas.clientHeight;
      initNodes();
    };
    
    const initNodes = () => {
       nodes = [];
       // Student Node (Center)
       nodes.push({ x: canvas.width / 2, y: canvas.height / 2, type: 'CORE', r: 15, pulse: 0 });
       
       // Satellite Nodes (Guardians)
       for(let i=0; i<5; i++) {
         nodes.push({
           x: Math.random() * canvas.width,
           y: Math.random() * canvas.height,
           type: 'SAT',
           vx: (Math.random() - 0.5) * 0.5,
           vy: (Math.random() - 0.5) * 0.5,
           r: 4
         });
       }
    };
    
    window.addEventListener('resize', resize);
    resize();

    const draw = () => {
      ctx.fillStyle = 'rgba(0,0,0,0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const core = nodes[0];
      core.pulse += 0.05;

      // Draw Connections
      nodes.forEach((node, i) => {
        if (i === 0) return; // Skip core loop
        
        // Move satellites
        node.x += node.vx;
        node.y += node.vy;
        
        // Bounce
        if (node.x < 0 || node.x > canvas.width) node.vx *= -1;
        if (node.y < 0 || node.y > canvas.height) node.vy *= -1;

        // Line to Core
        const dx = core.x - node.x;
        const dy = core.y - node.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        
        const opacity = active ? Math.max(0, 1 - dist/300) : 0.1;
        
        ctx.beginPath();
        ctx.strokeStyle = active ? `rgba(99, 102, 241, ${opacity})` : `rgba(100,100,100,${opacity})`;
        ctx.lineWidth = active ? 2 : 0.5;
        ctx.moveTo(core.x, core.y);
        ctx.lineTo(node.x, node.y);
        ctx.stroke();

        // Draw Satellite
        ctx.fillStyle = active ? '#22d3ee' : '#4b5563';
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.r, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw Core
      const pulseSize = active ? Math.sin(core.pulse) * 5 : 0;
      ctx.shadowBlur = active ? 20 : 0;
      ctx.shadowColor = '#6366f1';
      ctx.fillStyle = active ? '#6366f1' : '#374151';
      ctx.beginPath();
      ctx.arc(core.x, core.y, core.r + pulseSize, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [active]);

  return <canvas ref={canvasRef} className="w-full h-full absolute inset-0 rounded-2xl" />;
};

// --- Connection Modal ---
const ConnectModal = ({ onClose }: { onClose: () => void }) => {
  const [mode, setMode] = useState<'LINK' | 'EMAIL'>('LINK');
  const [inviteEmail, setInviteEmail] = useState('');
  const [status, setStatus] = useState<'IDLE' | 'SENDING' | 'SENT'>('IDLE');
  const [copied, setCopied] = useState(false);
  
  const inviteLink = "https://lumina.ai/link/8842-XZY-99";

  const handleCopy = () => {
    navigator.clipboard.writeText(inviteLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail) return;
    setStatus('SENDING');
    await new Promise(resolve => setTimeout(resolve, 2000)); // Sim delay
    setStatus('SENT');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in p-4">
      <div className="bg-[#0B0F19] w-full max-w-2xl rounded-3xl border border-indigo-500/30 shadow-[0_0_50px_rgba(79,70,229,0.2)] overflow-hidden flex flex-col md:flex-row relative">
         <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-white z-20">
            <X className="w-6 h-6" />
         </button>

         {/* Left: Visualization */}
         <div className="w-full md:w-5/12 h-48 md:h-auto bg-black relative border-b md:border-b-0 md:border-r border-white/10">
            <NeuralLinkVisualizer active={true} />
            <div className="absolute bottom-4 left-4 z-10">
               <h3 className="text-white font-bold text-lg leading-none">Neural Link</h3>
               <p className="text-cyan-400 text-xs font-mono animate-pulse">ESTABLISHING HANDSHAKE...</p>
            </div>
         </div>

         {/* Right: Controls */}
         <div className="w-full md:w-7/12 p-8">
            <h2 className="text-2xl font-black text-white mb-6">Initialize Uplink</h2>
            
            {/* Tabs */}
            <div className="flex gap-4 mb-6 border-b border-white/10 pb-4">
               <button 
                 onClick={() => setMode('LINK')}
                 className={`text-sm font-bold pb-2 transition-colors ${mode === 'LINK' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-gray-500 hover:text-gray-300'}`}
               >
                 SECURE LINK
               </button>
               <button 
                 onClick={() => setMode('EMAIL')}
                 className={`text-sm font-bold pb-2 transition-colors ${mode === 'EMAIL' ? 'text-indigo-400 border-b-2 border-indigo-400' : 'text-gray-500 hover:text-gray-300'}`}
               >
                 DIRECT TRANSMISSION
               </button>
            </div>

            {mode === 'LINK' ? (
              <div className="space-y-4 animate-fade-in">
                 <p className="text-gray-400 text-sm">Share this holographic frequency with your guardian to establish an immediate dashboard connection.</p>
                 <div className="bg-black/50 border border-white/10 rounded-xl p-4 flex items-center justify-between group hover:border-cyan-500/50 transition-colors">
                    <code className="text-cyan-300 text-xs md:text-sm font-mono truncate">{inviteLink}</code>
                    <button 
                      onClick={handleCopy}
                      className="p-2 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"
                    >
                       {copied ? <Check className="w-4 h-4 text-green-400" /> : <Share2 className="w-4 h-4" />}
                    </button>
                 </div>
                 {copied && <p className="text-xs text-green-400 font-mono text-center">FREQUENCY COPIED TO CLIPBOARD</p>}
              </div>
            ) : (
              <form onSubmit={handleSendInvite} className="space-y-4 animate-fade-in">
                 <p className="text-gray-400 text-sm">Target a guardian's comms device directly.</p>
                 <div className="relative">
                    <Mail className="absolute left-3 top-3.5 w-5 h-5 text-gray-500" />
                    <input 
                      type="email" 
                      placeholder="guardian@example.com"
                      value={inviteEmail}
                      onChange={e => setInviteEmail(e.target.value)}
                      className="w-full bg-black/50 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-white focus:border-indigo-500 outline-none"
                    />
                 </div>
                 <button 
                   type="submit"
                   disabled={status !== 'IDLE' || !inviteEmail}
                   className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl transition-all shadow-[0_0_20px_rgba(99,102,241,0.3)] disabled:opacity-50 disabled:shadow-none flex items-center justify-center gap-2"
                 >
                    {status === 'SENDING' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wifi className="w-4 h-4" />}
                    {status === 'IDLE' ? 'TRANSMIT SIGNAL' : status === 'SENDING' ? 'TRANSMITTING...' : 'SIGNAL LOCKED'}
                 </button>
                 {status === 'SENT' && (
                    <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg text-green-400 text-xs font-bold text-center">
                       INVITATION PROTOCOL EXECUTED SUCCESSFULLY
                    </div>
                 )}
              </form>
            )}
         </div>
      </div>
    </div>
  );
};

export const ParentConnect: React.FC = () => {
  const [report, setReport] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showConnect, setShowConnect] = useState(false);

  const handleGenerateReport = async () => {
    setLoading(true);
    try {
      const stats = {
        attendance: 92,
        math: 80,
        science: 88,
        english: 86,
        history: 70,
        sports: 92,
        cultural: 85
      };
      const text = await generateParentReport(stats);
      setReport(text);
    } catch (e) {
      alert("Could not generate report");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in pb-10">
      {/* Connection Modal */}
      {showConnect && <ConnectModal onClose={() => setShowConnect(false)} />}

      {/* Header */}
      <div className="bg-[#050914] p-8 rounded-3xl shadow-2xl border border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/20 to-transparent pointer-events-none"></div>
        
        {/* Animated Grid Background */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] opacity-30"></div>

        <div className="relative z-10">
          <h2 className="text-3xl font-black text-white mb-1 tracking-tight">GUARDIAN COMMAND CENTER</h2>
          <p className="text-gray-400">Target Subject: <span className="font-bold text-cyan-400 font-mono">ALEX JOHNSON [ID: 8842]</span></p>
        </div>
        
        <div className="relative z-10 flex flex-col md:flex-row gap-4 items-center">
            {/* Connection Trigger */}
            <button 
              onClick={() => setShowConnect(true)}
              className="px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/20 hover:border-cyan-400/50 rounded-xl text-white font-bold transition-all flex items-center gap-2 group/btn"
            >
               <div className="relative">
                 <Link className="w-4 h-4 text-cyan-400 group-hover/btn:animate-pulse" />
                 <div className="absolute inset-0 bg-cyan-400 blur-sm opacity-50"></div>
               </div>
               ESTABLISH UPLINK
            </button>

            <div className="flex items-center gap-3 px-5 py-2 bg-emerald-500/10 text-emerald-400 rounded-full text-sm font-bold border border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.2)]">
            <Activity className="w-4 h-4 animate-pulse" />
            SYSTEM OPTIMAL
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Biometric Attendance Section */}
        <div className="bg-[#0B0F19] p-8 rounded-3xl border border-white/5 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
             <ScanFace className="w-32 h-32 text-indigo-500" />
          </div>

          <div className="flex items-center justify-between mb-8 relative z-10">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-indigo-500" />
              Biometric Logs
            </h3>
            <span className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">92%</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 relative z-10">
            <div className="bg-black/30 rounded-2xl p-5 border border-white/5">
              <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">Recent Entries</h4>
              <div className="space-y-4">
                {attendanceLog.map((log, idx) => (
                  <div key={idx} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-3">
                      <div className={`w-1.5 h-1.5 rounded-full ${log.status === 'Present' ? 'bg-emerald-500 shadow-[0_0_5px_lime]' : 'bg-amber-500 shadow-[0_0_5px_orange]'}`}></div>
                      <span className="text-gray-300 font-medium">{log.date}</span>
                    </div>
                    <div className="text-right">
                       <span className="block font-bold text-white font-mono">{log.time}</span>
                       <span className="text-[10px] text-gray-500 uppercase">{log.method}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* AI Insight */}
            <div className="bg-indigo-900/10 rounded-2xl p-5 border border-indigo-500/20 flex flex-col">
               <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                 <Sparkles className="w-3 h-3" /> Pattern Detected
               </h4>
               <p className="text-sm text-indigo-200 leading-relaxed mb-4 flex-1">
                 Subject shows recurring latency (10-15m) on Wednesdays. Correlates with late-night Tuesday study sessions.
               </p>
               <div className="space-y-2">
                  <div className="flex items-center gap-2 text-[10px] font-bold text-orange-300 bg-orange-900/20 p-2 rounded border border-orange-500/20">
                    <Trophy className="w-3 h-3" />
                    ATHLETICS: ELITE TIER
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-pink-300 bg-pink-900/20 p-2 rounded border border-pink-500/20">
                    <Music className="w-3 h-3" />
                    ARTS: LEAD PERFORMER
                  </div>
               </div>
            </div>
          </div>
        </div>

        {/* Performance Graph */}
        <div className="bg-[#0B0F19] p-8 rounded-3xl border border-white/5 flex flex-col">
           <div className="flex items-center justify-between mb-8">
             <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-cyan-500" />
                Performance Metrics
              </h3>
              <div className="flex gap-2">
                <span className="px-2 py-1 bg-orange-500/10 text-orange-400 border border-orange-500/20 text-[10px] rounded font-bold uppercase">Sports</span>
                <span className="px-2 py-1 bg-pink-500/10 text-pink-400 border border-pink-500/20 text-[10px] rounded font-bold uppercase">Cultural</span>
              </div>
           </div>
            
            <div className="h-64 flex-1 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weeklyPerformanceData} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorMath" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorSci" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} />
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1f2937" />
                  <Tooltip 
                     contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: '1px solid #374151', color: '#fff' }} 
                     itemStyle={{ color: '#fff' }}
                  />
                  <Legend iconType="circle" />
                  <Area type="monotone" dataKey="Math" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorMath)" />
                  <Area type="monotone" dataKey="Science" stroke="#06b6d4" strokeWidth={3} fillOpacity={1} fill="url(#colorSci)" />
                  <Area type="monotone" dataKey="English" stroke="#f59e0b" fillOpacity={0} strokeWidth={2} />
                  
                  {/* Extracurriculars */}
                  <Area type="monotone" dataKey="Sports" stroke="#f97316" fillOpacity={0.05} fill="#f97316" strokeWidth={2} strokeDasharray="4 4" />
                  <Area type="monotone" dataKey="Cultural" stroke="#ec4899" fillOpacity={0.05} fill="#ec4899" strokeWidth={2} strokeDasharray="4 4" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
        </div>
      </div>

      {/* AI Report Generator Section */}
      <div className="relative rounded-3xl p-[2px] bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-500 shadow-2xl">
        <div className="bg-[#050914] rounded-[22px] p-8 md:p-10 relative overflow-hidden">
           {/* Background Mesh */}
           <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
           
           <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 relative z-10">
             <div className="flex-1">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 border border-indigo-500/30 rounded-full text-indigo-300 text-xs font-bold uppercase mb-4">
                   <FileText className="w-3 h-3" /> Intelligence Briefing
                </div>
                <h3 className="text-2xl font-black text-white mb-2">Generate Weekly Guardian Report</h3>
                <p className="text-gray-400 max-w-2xl">
                  Compile all academic, athletic, and behavioral data into a cohesive summary using the latest neural processing model.
                </p>
             </div>
             <button 
               onClick={handleGenerateReport}
               disabled={loading}
               className="px-8 py-4 bg-white text-black font-black rounded-xl hover:bg-gray-200 transition-all shadow-[0_0_30px_rgba(255,255,255,0.2)] disabled:opacity-70 flex items-center gap-3 whitespace-nowrap active:scale-95"
             >
               {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5 text-indigo-600" />}
               {loading ? "PROCESSING..." : "COMPILE REPORT"}
             </button>
           </div>

           {report && (
             <div className="mt-10 bg-white/5 rounded-xl p-8 border border-white/10 animate-fade-in-up relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 to-cyan-500"></div>
                <h4 className="text-sm font-bold text-gray-500 uppercase tracking-widest mb-4">Executive Summary</h4>
                <p className="leading-loose text-lg text-gray-200 font-light">{report}</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};