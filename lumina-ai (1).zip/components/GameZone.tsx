import React, { useState, useEffect, useRef } from 'react';
import { Gamepad2, Trophy, Zap, Brain, Rocket, FlaskConical, Globe, Code, ArrowRight, Loader2, Play, RefreshCw, Heart, Target, Crosshair } from 'lucide-react';
import { generateBubbleLevel } from '../services/gemini';
import { BubbleGameLevel } from '../types';

const subjects = [
  { id: 'Math', name: 'Math Blaster', icon: Brain, color: 'from-blue-500 to-cyan-500', shadow: 'shadow-blue-500/40', accent: '#3b82f6' },
  { id: 'Science', name: 'Atom Pop', icon: FlaskConical, color: 'from-green-500 to-emerald-500', shadow: 'shadow-green-500/40', accent: '#10b981' },
  { id: 'History', name: 'Time Warp', icon: Globe, color: 'from-orange-500 to-amber-500', shadow: 'shadow-orange-500/40', accent: '#f59e0b' },
  { id: 'Coding', name: 'Cyber Syntax', icon: Code, color: 'from-purple-500 to-violet-500', shadow: 'shadow-purple-500/40', accent: '#8b5cf6' },
  { id: 'Space', name: 'Galaxy Quest', icon: Rocket, color: 'from-indigo-500 to-blue-600', shadow: 'shadow-indigo-500/40', accent: '#6366f1' },
];

// 3D Bubble Interface
interface Bubble3D {
  id: number;
  x: number; // World X
  y: number; // World Y
  z: number; // Depth (Distance from camera)
  radius: number;
  text: string;
  isCorrect: boolean;
  color: string;
  rotation: number;
}

interface Star {
  x: number;
  y: number;
  z: number;
}

export const GameZone: React.FC = () => {
  const [view, setView] = useState<'MENU' | 'LOADING' | 'PLAYING' | 'GAMEOVER'>('MENU');
  const [currentSubject, setCurrentSubject] = useState<string>('');
  const [gameLevel, setGameLevel] = useState<BubbleGameLevel | null>(null);
  
  // Game UI State
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);

  // Canvas Refs
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>(0);
  
  // Game Logic Refs (Mutable)
  const bubblesRef = useRef<Bubble3D[]>([]);
  const starsRef = useRef<Star[]>([]);
  const gameStateRef = useRef({
    lastSpawnTime: 0,
    spawnInterval: 2500, // Slower spawn for 3D navigation
    isPlaying: false,
    score: 0,
    lives: 3,
    width: 0,
    height: 0,
    mouseX: 0,
    mouseY: 0,
    isClicking: false,
    speedBase: 5 // Base speed of Z movement
  });

  // Init Game
  const initGame = async (subject: string) => {
    setCurrentSubject(subject);
    setView('LOADING');
    try {
      const data = await generateBubbleLevel(subject);
      setGameLevel(data);
      setScore(0);
      setLives(3);
      setCurrentQuestionIdx(0);
      gameStateRef.current.score = 0;
      gameStateRef.current.lives = 3;
      gameStateRef.current.spawnInterval = 2000;
      gameStateRef.current.speedBase = 5;
      setView('PLAYING');
    } catch (e) {
      console.error(e);
      alert("Failed to load game level. Please try again.");
      setView('MENU');
    }
  };

  // 3D Game Loop
  useEffect(() => {
    if (view !== 'PLAYING' || !gameLevel) {
       cancelAnimationFrame(requestRef.current);
       gameStateRef.current.isPlaying = false;
       return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize
    const resize = () => {
      if(canvas) {
        canvas.width = canvas.clientWidth || window.innerWidth;
        canvas.height = canvas.clientHeight || window.innerHeight;
        gameStateRef.current.width = canvas.width;
        gameStateRef.current.height = canvas.height;
      }
    };
    resize();
    window.addEventListener('resize', resize);

    // Initialize Stars
    starsRef.current = Array.from({ length: 100 }, () => ({
      x: (Math.random() - 0.5) * 2000,
      y: (Math.random() - 0.5) * 2000,
      z: Math.random() * 2000
    }));

    gameStateRef.current.isPlaying = true;
    bubblesRef.current = [];
    gameStateRef.current.lastSpawnTime = performance.now();

    const spawnBubble = () => {
       if (!gameLevel.questions[currentQuestionIdx]) return;
       
       const isCorrect = Math.random() > 0.6;
       const text = isCorrect 
         ? gameLevel.questions[currentQuestionIdx].answer 
         : gameLevel.decoys[Math.floor(Math.random() * gameLevel.decoys.length)];

       // Spawn far away (Z = 2000)
       // X and Y are random spread
       bubblesRef.current.push({
         id: Date.now() + Math.random(),
         x: (Math.random() - 0.5) * 1500, // World X spread
         y: (Math.random() - 0.5) * 1000, // World Y spread
         z: 2000, // Spawn distance
         radius: 60, // Base radius
         text,
         isCorrect: text === gameLevel.questions[currentQuestionIdx].answer,
         color: `hsl(${Math.random() * 360}, 80%, 60%)`,
         rotation: Math.random() * Math.PI * 2
       });
    };

    const update = (time: number) => {
      if (!gameStateRef.current.isPlaying) return;

      const width = gameStateRef.current.width;
      const height = gameStateRef.current.height;
      const cx = width / 2;
      const cy = height / 2;
      const focalLength = 400; // Adjusts FOV

      // Clear & Background
      const gradient = ctx.createRadialGradient(cx, cy, 10, cx, cy, width);
      gradient.addColorStop(0, '#0f172a');
      gradient.addColorStop(1, '#000000');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Draw Stars (Warp Effect)
      ctx.fillStyle = '#ffffff';
      for(const star of starsRef.current) {
        star.z -= gameStateRef.current.speedBase * 2;
        if (star.z <= 1) {
           star.z = 2000;
           star.x = (Math.random() - 0.5) * 2000;
           star.y = (Math.random() - 0.5) * 2000;
        }
        
        const scale = focalLength / (focalLength + star.z);
        const sx = cx + star.x * scale;
        const sy = cy + star.y * scale;
        const sSize = 2 * scale;

        ctx.globalAlpha = Math.min(1, scale * 2);
        ctx.beginPath();
        ctx.arc(sx, sy, sSize, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // Spawn Logic
      if (time - gameStateRef.current.lastSpawnTime > gameStateRef.current.spawnInterval) {
         spawnBubble();
         gameStateRef.current.lastSpawnTime = time;
         gameStateRef.current.spawnInterval = Math.max(800, gameStateRef.current.spawnInterval - 10);
      }

      // Update & Draw Bubbles (Sort by Z desc aka Painter's Algorithm)
      bubblesRef.current.sort((a, b) => b.z - a.z);

      for (let i = bubblesRef.current.length - 1; i >= 0; i--) {
        const b = bubblesRef.current[i];
        
        // Move towards camera
        b.z -= gameStateRef.current.speedBase;
        b.rotation += 0.01;

        // Passed Camera?
        if (b.z <= -focalLength + 100) {
           bubblesRef.current.splice(i, 1);
           if (b.isCorrect) {
             // Missed a correct answer!
             // Optional penalty?
           }
           continue;
        }

        // Projection
        const scale = focalLength / (focalLength + b.z);
        const sx = cx + b.x * scale;
        const sy = cy + b.y * scale;
        const sRadius = b.radius * scale;

        // Skip if too small or behind
        if (scale <= 0) continue;

        // Interaction (Raycasting-ish approximation)
        // Check distance from mouse to projected center
        if (gameStateRef.current.isClicking) {
           const dx = gameStateRef.current.mouseX - sx;
           const dy = gameStateRef.current.mouseY - sy;
           // Hitbox slightly larger than visual radius for better UX
           if (Math.sqrt(dx*dx + dy*dy) < sRadius * 1.2) {
              
              // Hit!
              bubblesRef.current.splice(i, 1);
              gameStateRef.current.isClicking = false; 

              if (b.isCorrect) {
                 gameStateRef.current.score += 100;
                 setScore(gameStateRef.current.score);
                 // Next question?
                 if (currentQuestionIdx < gameLevel.questions.length - 1) {
                   setCurrentQuestionIdx(prev => prev + 1);
                   gameStateRef.current.speedBase += 0.5; // Speed up
                 } else {
                   setView('GAMEOVER');
                 }
              } else {
                 gameStateRef.current.lives -= 1;
                 setLives(gameStateRef.current.lives);
                 if (gameStateRef.current.lives <= 0) setView('GAMEOVER');
              }
              continue; // Next bubble
           }
        }

        // DRAW 3D BUBBLE
        // Halo effect for correct answers (subtle hint) or just style
        const alpha = Math.min(1, Math.max(0, 1 - (b.z / 2000))); // Fade in
        
        ctx.save();
        ctx.globalAlpha = alpha;
        
        // Sphere Gradient
        const grad = ctx.createRadialGradient(sx - sRadius/3, sy - sRadius/3, sRadius/10, sx, sy, sRadius);
        grad.addColorStop(0, '#ffffff');
        grad.addColorStop(0.2, b.color);
        grad.addColorStop(1, adjustColorBrightness(b.color, -50)); // Darker edge
        
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(sx, sy, sRadius, 0, Math.PI * 2);
        ctx.fill();

        // Rim Light
        ctx.strokeStyle = 'rgba(255,255,255,0.4)';
        ctx.lineWidth = 2 * scale;
        ctx.stroke();

        // Inner Content (Text)
        ctx.fillStyle = '#fff';
        ctx.font = `bold ${Math.max(10, 24 * scale)}px Inter, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor = 'rgba(0,0,0,0.8)';
        ctx.shadowBlur = 10 * scale;
        ctx.fillText(b.text, sx, sy);
        
        ctx.restore();
      }

      gameStateRef.current.isClicking = false; // Reset click
      requestRef.current = requestAnimationFrame(update);
    };

    requestRef.current = requestAnimationFrame(update);

    return () => {
       window.removeEventListener('resize', resize);
       cancelAnimationFrame(requestRef.current);
       gameStateRef.current.isPlaying = false;
    };
  }, [view, gameLevel, currentQuestionIdx]);

  // Handle Interaction
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
     if (view !== 'PLAYING') return;
     const rect = canvasRef.current?.getBoundingClientRect();
     if (rect) {
        gameStateRef.current.mouseX = e.clientX - rect.left;
        gameStateRef.current.mouseY = e.clientY - rect.top;
        gameStateRef.current.isClicking = true;
     }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (view !== 'PLAYING') return;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (rect) {
       gameStateRef.current.mouseX = e.clientX - rect.left;
       gameStateRef.current.mouseY = e.clientY - rect.top;
    }
  };

  // Helper for 3D Card tilt
  const Card3D = ({ subject }: { subject: any }) => {
    const Icon = subject.icon;
    const [rotate, setRotate] = useState({ x: 0, y: 0 });

    const handleMove = (e: React.MouseEvent<HTMLButtonElement>) => {
       const rect = e.currentTarget.getBoundingClientRect();
       const x = e.clientX - rect.left; // x position within the element.
       const y = e.clientY - rect.top;  // y position within the element.
       const centerX = rect.width / 2;
       const centerY = rect.height / 2;
       
       const rotateX = ((y - centerY) / centerY) * -10; // Max 10 deg
       const rotateY = ((x - centerX) / centerX) * 10;

       setRotate({ x: rotateX, y: rotateY });
    };

    const handleLeave = () => setRotate({ x: 0, y: 0 });

    return (
      <button
        onClick={() => initGame(subject.id)}
        onMouseMove={handleMove}
        onMouseLeave={handleLeave}
        className="relative group h-64 rounded-2xl transition-all duration-200"
        style={{
           perspective: '1000px',
        }}
      >
         <div 
           className="w-full h-full bg-white rounded-2xl border border-gray-100 shadow-xl overflow-hidden relative flex flex-col items-center justify-center p-6 transition-transform duration-100 ease-out"
           style={{
              transform: `rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) scale3d(1, 1, 1)`,
              boxShadow: `${-rotate.y * 2}px ${rotate.x * 2}px 20px rgba(0,0,0,0.1)`
           }}
         >
            <div className={`absolute inset-0 bg-gradient-to-br ${subject.color} opacity-0 group-hover:opacity-10 transition-opacity`}></div>
            
            <div className="transform translate-z-10 group-hover:scale-110 transition-transform duration-300">
               <div className={`w-20 h-20 rounded-2xl mb-6 flex items-center justify-center text-white shadow-lg bg-gradient-to-br ${subject.color}`}>
                  <Icon className="w-10 h-10" />
               </div>
            </div>
            
            <h3 className="text-2xl font-black text-gray-800 mb-2 transform translate-z-5">{subject.name}</h3>
            <p className="text-sm text-gray-400 font-medium">Interactive 3D Mode</p>
         </div>
      </button>
    );
  };

  return (
    <div className="h-full animate-fade-in relative overflow-hidden flex flex-col bg-gray-50">
      
      {/* MENU VIEW */}
      {view === 'MENU' && (
        <div className="relative z-10 flex flex-col items-center justify-center min-h-full p-4">
           {/* Background Grid */}
           <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.05)_1px,transparent_1px)] bg-[size:40px_40px] [transform:perspective(1000px)_rotateX(60deg)_scale(2)] origin-top pointer-events-none"></div>

           <div className="text-center mb-12 relative z-10">
              <span className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-4">
                 <Rocket className="w-3 h-3" /> Immersive Engine 2.0
              </span>
              <h1 className="text-6xl font-black text-gray-900 mb-4 tracking-tighter drop-shadow-sm">
                Game<span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">Zone 3D</span>
              </h1>
              <p className="text-gray-500 text-lg max-w-md mx-auto">
                Select a mission. Navigate the tunnel. Target the correct answers in 3D space.
              </p>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-5xl px-4 perspective-container">
              {subjects.map((sub) => (
                 <Card3D key={sub.id} subject={sub} />
              ))}
           </div>
        </div>
      )}

      {/* LOADING VIEW */}
      {view === 'LOADING' && (
        <div className="flex-1 flex flex-col items-center justify-center bg-black">
           <div className="w-20 h-20 relative">
              <div className="absolute inset-0 border-4 border-indigo-500/30 rounded-full animate-ping"></div>
              <div className="absolute inset-0 border-4 border-t-indigo-500 rounded-full animate-spin"></div>
           </div>
           <p className="text-2xl font-bold text-white mt-8 tracking-widest uppercase">Initializing Environment</p>
           <p className="text-indigo-400 mt-2 font-mono">Loading assets for {currentSubject}...</p>
        </div>
      )}

      {/* PLAYING VIEW */}
      {view === 'PLAYING' && gameLevel && (
        <div className="flex-1 relative flex flex-col h-full w-full bg-black cursor-none">
           {/* HUD */}
           <div className="absolute top-0 left-0 w-full z-20 p-6 flex justify-between items-start pointer-events-none">
              <div className="bg-black/50 backdrop-blur-md shadow-[0_0_20px_rgba(99,102,241,0.3)] rounded-2xl p-6 border border-indigo-500/30 animate-slide-down">
                 <p className="text-xs font-bold text-indigo-300 uppercase tracking-widest mb-2">Current Objective</p>
                 <h2 className="text-3xl font-black text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
                    {gameLevel.questions[currentQuestionIdx]?.text}
                 </h2>
              </div>
              
              <div className="flex flex-col gap-4 items-end">
                 <div className="bg-black/50 backdrop-blur-md rounded-xl px-6 py-3 border border-gray-700/50 flex items-center gap-4">
                    <div className="text-right">
                       <p className="text-[10px] font-bold text-gray-400 uppercase">Score</p>
                       <p className="text-2xl font-black text-white font-mono">{score.toString().padStart(6, '0')}</p>
                    </div>
                    <Trophy className="w-8 h-8 text-yellow-500" />
                 </div>
                 
                 <div className="flex gap-1">
                    {[...Array(3)].map((_, i) => (
                       <div key={i} className={`w-8 h-2 rounded-full transition-all ${i < lives ? 'bg-red-500 shadow-[0_0_10px_red]' : 'bg-gray-800'}`}></div>
                    ))}
                 </div>
              </div>
           </div>

           {/* CANVAS */}
           <canvas
             ref={canvasRef}
             onClick={handleCanvasClick}
             onMouseMove={handleMouseMove}
             className="w-full h-full block"
           />

           {/* Custom Cursor (Reticle) */}
           <div 
             className="fixed w-12 h-12 border-2 border-white/50 rounded-full pointer-events-none transform -translate-x-1/2 -translate-y-1/2 mix-blend-difference z-50 flex items-center justify-center"
             style={{ 
               left: gameStateRef.current.mouseX, 
               top: gameStateRef.current.mouseY 
             }}
           >
              <div className="w-1 h-1 bg-red-500 rounded-full"></div>
              <div className="absolute w-full h-full border border-white/20 rounded-full animate-ping"></div>
              <Crosshair className="absolute w-16 h-16 text-white/30" strokeWidth={1} />
           </div>
        </div>
      )}

      {/* GAME OVER VIEW */}
      {view === 'GAMEOVER' && (
         <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/90 backdrop-blur-xl animate-fade-in">
            <div className="bg-gray-900 p-10 rounded-3xl shadow-2xl text-center max-w-lg w-full border border-gray-800 relative overflow-hidden">
               {/* Background Glow */}
               <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-indigo-500/10 to-transparent pointer-events-none"></div>

               {lives > 0 ? (
                  <div className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-[0_0_30px_rgba(250,204,21,0.4)]">
                     <Trophy className="w-12 h-12 text-white" />
                  </div>
               ) : (
                  <div className="w-24 h-24 bg-gradient-to-br from-red-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-8 shadow-[0_0_30px_rgba(239,68,68,0.4)]">
                     <RefreshCw className="w-12 h-12 text-white" />
                  </div>
               )}
               
               <h2 className="text-4xl font-black text-white mb-2 tracking-tight">
                 {lives > 0 ? 'MISSION COMPLETE' : 'SYSTEM FAILURE'}
               </h2>
               <p className="text-gray-400 mb-8 text-lg">
                 {lives > 0 ? 'All targets neutralized successfully.' : 'Mission aborted. Try again.'}
               </p>
               
               <div className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400 mb-10 font-mono">
                  {score}
               </div>

               <div className="space-y-4">
                  <button 
                    onClick={() => initGame(currentSubject)}
                    className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/30 transition-all active:scale-95 flex items-center justify-center gap-2 text-lg"
                  >
                     <Play className="w-6 h-6 fill-current" /> RESTART MISSION
                  </button>
                  <button 
                    onClick={() => setView('MENU')}
                    className="w-full py-4 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-xl font-bold transition-colors text-lg"
                  >
                     RETURN TO BASE
                  </button>
               </div>
            </div>
         </div>
      )}
    </div>
  );
};

// Helper
function adjustColorBrightness(color: string, amount: number) {
  return '#' + color.replace(/^#/, '').replace(/../g, color => ('0'+Math.min(255, Math.max(0, parseInt(color, 16) + amount)).toString(16)).substr(-2));
}