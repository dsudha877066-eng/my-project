import React, { useState, useEffect } from 'react';
import { BrainCircuit, Loader2, Check, X, ChevronRight, RotateCw, Mail, Send, Activity, Target, Trophy } from 'lucide-react';
import { generateQuiz, generateDailyEmail } from '../services/gemini';
import { QuizData, QuizQuestion } from '../types';

interface QuizModeProps {
  initialTopic?: string;
}

export const QuizMode: React.FC<QuizModeProps> = ({ initialTopic = '' }) => {
  const [topic, setTopic] = useState(initialTopic);
  const [difficulty, setDifficulty] = useState('Medium');
  const [quizData, setQuizData] = useState<QuizData | null>(null);
  const [loading, setLoading] = useState(false);
  
  // Quiz State
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  
  // Report State
  const [sendingReport, setSendingReport] = useState(false);
  const [reportSent, setReportSent] = useState(false);

  useEffect(() => {
    if (initialTopic) setTopic(initialTopic);
  }, [initialTopic]);

  const handleStartQuiz = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if(!topic) return;

    setLoading(true);
    setQuizData(null);
    setQuizCompleted(false);
    setCurrentQuestionIndex(0);
    setScore(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setReportSent(false);

    try {
      const data = await generateQuiz(topic, difficulty);
      setQuizData(data);
    } catch (err) {
      alert("Could not generate quiz. Try a different topic.");
    } finally {
      setLoading(false);
    }
  };

  const handleOptionSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null || !quizData) return;
    
    setIsAnswered(true);
    if (selectedOption === quizData.questions[currentQuestionIndex].correctAnswerIndex) {
      setScore(s => s + 1);
    }
  };

  const handleNextQuestion = () => {
    if (!quizData) return;
    
    if (currentQuestionIndex < quizData.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const handleRetry = () => {
      setQuizData(null);
      setTopic('');
      setReportSent(false);
  };

  const handleSendReport = async () => {
    if (!quizData) return;
    setSendingReport(true);
    try {
      await generateDailyEmail(quizData.topic, score, quizData.questions.length);
      await new Promise(resolve => setTimeout(resolve, 1500));
      setReportSent(true);
    } catch (e) {
      alert("Failed to send report");
    } finally {
      setSendingReport(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-full min-h-[400px]">
        <div className="relative w-24 h-24 mb-6">
           <div className="absolute inset-0 border-4 border-indigo-500/30 rounded-full animate-ping"></div>
           <div className="absolute inset-0 border-4 border-t-cyan-500 rounded-full animate-spin"></div>
        </div>
        <h3 className="text-xl font-bold text-white tracking-widest">INITIALIZING SIMULATION</h3>
        <p className="text-cyan-400 font-mono text-sm mt-2">Constructing neural patterns for "{topic}"...</p>
      </div>
    );
  }

  // Quiz Results View
  if (quizCompleted && quizData) {
    const percentage = Math.round((score / quizData.questions.length) * 100);
    return (
      <div className="max-w-2xl mx-auto bg-black/40 backdrop-blur-xl p-10 rounded-3xl shadow-[0_0_50px_rgba(79,70,229,0.1)] border border-white/10 text-center animate-fade-in relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent"></div>
        
        <div className="w-24 h-24 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-indigo-500/30">
          <Trophy className="w-10 h-10 text-white" />
        </div>
        
        <h2 className="text-3xl font-black text-white mb-2 tracking-tight">TRAINING COMPLETE</h2>
        <p className="text-gray-400 mb-8 font-mono text-sm uppercase">Module: {quizData.topic}</p>
        
        <div className="text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400 mb-4 tracking-tighter">
            {percentage}%
        </div>
        <p className="text-lg text-gray-300 mb-8 border border-white/10 inline-block px-4 py-2 rounded-full bg-white/5">
            Accuracy: <span className="text-white font-bold">{score} / {quizData.questions.length}</span>
        </p>
        
        <div className="flex flex-col gap-3 max-w-sm mx-auto">
          {!reportSent ? (
            <button 
              onClick={handleSendReport}
              disabled={sendingReport}
              className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-emerald-600/80 hover:bg-emerald-500 text-white rounded-xl font-bold transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] disabled:opacity-50"
            >
              {sendingReport ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
              {sendingReport ? "TRANSMITTING..." : "TRANSMIT REPORT TO GUARDIAN"}
            </button>
          ) : (
             <div className="w-full px-6 py-4 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-xl flex items-center justify-center gap-2 font-mono text-sm">
               <Check className="w-5 h-5" />
               TRANSMISSION SUCCESSFUL
             </div>
          )}

          <button 
            onClick={handleRetry}
            className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-white/5 border border-white/10 text-gray-300 rounded-xl hover:bg-white/10 transition-colors font-bold"
          >
            <RotateCw className="w-4 h-4" />
            RESTART MODULE
          </button>
        </div>
      </div>
    );
  }

  // Active Quiz View
  if (quizData) {
    const question = quizData.questions[currentQuestionIndex];
    return (
      <div className="max-w-4xl mx-auto flex flex-col h-[600px] relative">
         {/* Background Glow */}
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-indigo-500/5 blur-[100px] pointer-events-none"></div>

         <div className="bg-black/40 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/10 overflow-hidden flex flex-col h-full relative z-10">
            {/* Header */}
            <div className="bg-white/5 px-8 py-5 border-b border-white/5 flex justify-between items-center">
               <div className="flex items-center gap-3">
                  <Activity className="w-5 h-5 text-cyan-400" />
                  <span className="font-bold text-gray-200 tracking-wide uppercase">{quizData.topic}</span>
               </div>
               <div className="flex items-center gap-3">
                  <div className="w-32 h-2 bg-gray-800 rounded-full overflow-hidden">
                     <div 
                        className="h-full bg-cyan-500 shadow-[0_0_10px_cyan] transition-all duration-500" 
                        style={{ width: `${((currentQuestionIndex + 1) / quizData.questions.length) * 100}%` }}
                     ></div>
                  </div>
                  <span className="text-xs font-mono text-cyan-400">
                    {currentQuestionIndex + 1}/{quizData.questions.length}
                  </span>
               </div>
            </div>

            {/* Content */}
            <div className="p-8 flex-1 flex flex-col overflow-y-auto">
               <h3 className="text-2xl font-bold text-white mb-8 leading-relaxed">
                  {question.question}
               </h3>
              
               <div className="space-y-4 flex-1">
                  {question.options.map((option, idx) => {
                     let btnClass = "w-full text-left p-5 rounded-xl border transition-all duration-200 group relative overflow-hidden ";
                     
                     if (isAnswered) {
                        if (idx === question.correctAnswerIndex) {
                          btnClass += "border-emerald-500/50 bg-emerald-500/10 text-white shadow-[0_0_15px_rgba(16,185,129,0.2)]";
                        } else if (idx === selectedOption) {
                          btnClass += "border-red-500/50 bg-red-500/10 text-white";
                        } else {
                          btnClass += "border-white/5 bg-transparent text-gray-500 opacity-50";
                        }
                     } else {
                        if (idx === selectedOption) {
                          btnClass += "border-indigo-500 bg-indigo-500/20 text-white shadow-[0_0_15px_rgba(99,102,241,0.3)]";
                        } else {
                          btnClass += "border-white/10 bg-white/5 text-gray-300 hover:border-indigo-400/50 hover:bg-white/10";
                        }
                     }

                     return (
                       <button
                         key={idx}
                         onClick={() => handleOptionSelect(idx)}
                         className={btnClass}
                         disabled={isAnswered}
                       >
                         <div className="flex items-center justify-between relative z-10">
                           <span className="font-medium text-lg">{option}</span>
                           {isAnswered && idx === question.correctAnswerIndex && <Check className="w-6 h-6 text-emerald-400" />}
                           {isAnswered && idx === selectedOption && idx !== question.correctAnswerIndex && <X className="w-6 h-6 text-red-400" />}
                         </div>
                       </button>
                     );
                  })}
               </div>

               {isAnswered && (
                  <div className="mt-8 p-6 bg-indigo-900/20 border-l-4 border-indigo-500 text-indigo-200 rounded-r-xl animate-fade-in-up">
                    <strong className="text-white block mb-1">ANALYSIS:</strong> {question.explanation}
                  </div>
               )}
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-white/5 bg-black/20 flex justify-end">
               {!isAnswered ? (
                  <button
                    onClick={handleSubmitAnswer}
                    disabled={selectedOption === null}
                    className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-indigo-600/30 disabled:opacity-50 disabled:shadow-none"
                  >
                    CONFIRM SELECTION
                  </button>
               ) : (
                  <button
                    onClick={handleNextQuestion}
                    className="px-8 py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-cyan-600/30 flex items-center gap-2"
                  >
                    {currentQuestionIndex < quizData.questions.length - 1 ? 'NEXT SEQUENCE' : 'FINALIZE'}
                    <ChevronRight className="w-5 h-5" />
                  </button>
               )}
            </div>
         </div>
      </div>
    );
  }

  // Initial Form
  return (
    <div className="max-w-2xl mx-auto mt-10">
      <div className="bg-[#050914] p-10 rounded-3xl shadow-2xl border border-white/10 text-center relative overflow-hidden group">
        {/* Animated BG */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-500 animate-gradient-x"></div>
        <div className="absolute -right-20 -top-20 w-64 h-64 bg-indigo-500/10 blur-[80px] rounded-full pointer-events-none"></div>

        <div className="w-20 h-20 bg-gray-900 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-inner border border-white/5 relative">
          <BrainCircuit className="w-10 h-10 text-cyan-400" />
          <div className="absolute inset-0 bg-cyan-500/20 blur-xl animate-pulse"></div>
        </div>

        <h2 className="text-3xl font-black text-white mb-2 tracking-tight">NEURAL TRAINING</h2>
        <p className="text-gray-400 mb-10 max-w-md mx-auto">
            Configure your simulation parameters. The AI will generate a unique challenge based on your selection.
        </p>

        <form onSubmit={handleStartQuiz} className="space-y-6 text-left max-w-md mx-auto">
          <div className="space-y-2">
            <label className="text-xs font-bold text-indigo-400 uppercase tracking-widest ml-1">Topic Input</label>
            <div className="relative">
               <input
                 type="text"
                 value={topic}
                 onChange={(e) => setTopic(e.target.value)}
                 placeholder="e.g. Quantum Mechanics, Roman Empire..."
                 className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all placeholder-gray-600 font-medium"
                 required
               />
               <Target className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-indigo-400 uppercase tracking-widest ml-1">Simulation Difficulty</label>
            <div className="grid grid-cols-3 gap-3">
              {['Easy', 'Medium', 'Hard'].map(level => (
                <button
                  key={level}
                  type="button"
                  onClick={() => setDifficulty(level)}
                  className={`py-3 rounded-xl text-sm font-bold border transition-all ${
                    difficulty === level 
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.4)]' 
                    : 'bg-white/5 border-transparent text-gray-500 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-indigo-600 to-cyan-600 text-white font-black py-4 rounded-xl hover:shadow-[0_0_30px_rgba(99,102,241,0.4)] transition-all active:scale-[0.98] mt-6 tracking-wide text-lg"
          >
            INITIATE SEQUENCE
          </button>
        </form>
      </div>
    </div>
  );
};