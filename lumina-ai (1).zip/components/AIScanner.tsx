import React, { useState, useRef, useEffect } from 'react';
import { ScanLine, Search, Loader2, Activity, Aperture, Zap, Sparkles, Hexagon, Terminal, RotateCcw, Box, ChevronRight, Cpu, Globe } from 'lucide-react';
import { scanTopic } from '../services/gemini';
import { ScanResult } from '../types';

// --- Holographic Projector (Procedural 3D Video) ---
const HoloProjector = ({ type }: { type: ScanResult['visualType'] }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: any[] = [];
    let time = 0;

    // Resize
    const resize = () => {
      canvas.width = canvas.clientWidth;
      canvas.height = canvas.clientHeight;
    };
    window.addEventListener('resize', resize);
    resize();

    // Init Logic based on Type
    const init = () => {
      particles = [];
      
      if (type === 'COSMOS') {
        // Solar System
        for (let i = 0; i < 5; i++) {
          particles.push({
            r: 40 + i * 35, // orbit radius
            size: 4 + Math.random() * 8,
            speed: (0.015 - i * 0.002) * (Math.random() > 0.5 ? 1 : -1),
            angle: Math.random() * Math.PI * 2,
            color: `hsl(${Math.random() * 360}, 70%, 60%)`
          });
        }
      } else if (type === 'ATOMIC') {
        // Electrons
        for (let i = 0; i < 12; i++) {
          particles.push({
            rx: 60 + Math.random() * 60,
            ry: 20 + Math.random() * 40,
            angle: Math.random() * Math.PI * 2,
            tilt: Math.random() * Math.PI,
            speed: 0.05 + Math.random() * 0.05,
            color: '#06b6d4'
          });
        }
      } else if (type === 'BIOLOGY') {
        // DNA Particles
        for (let i = 0; i < 50; i++) {
          particles.push({
            y: (i - 25) * 8,
            angle: i * 0.4,
            speed: 0.02,
            color: i % 2 === 0 ? '#ec4899' : '#10b981'
          });
        }
      }
      // Geometry & History handled in draw loop via functions
    };
    init();

    const draw = () => {
      // Clear with fade for trails
      ctx.fillStyle = 'rgba(2, 6, 23, 0.25)'; 
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      time += 0.01;

      ctx.save();
      ctx.translate(cx, cy);

      if (type === 'COSMOS') {
        // Star Background
        for(let i=0; i<20; i++) {
           const x = Math.sin(time * 0.1 + i) * 200;
           const y = Math.cos(time * 0.2 + i * 2) * 200;
           ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.5})`;
           ctx.fillRect(x,y, 1, 1);
        }

        // Sun
        const sunPulse = Math.sin(time * 2) * 2;
        ctx.shadowBlur = 40;
        ctx.shadowColor = '#f59e0b';
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(0, 0, 15 + sunPulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Planets
        particles.forEach(p => {
          p.angle += p.speed;
          const x = Math.cos(p.angle) * p.r;
          const y = Math.sin(p.angle) * p.r * 0.3; // Tilt orbit
          
          // Draw Orbit path
          ctx.strokeStyle = 'rgba(255,255,255,0.05)';
          ctx.beginPath();
          ctx.ellipse(0, 0, p.r, p.r * 0.3, 0, 0, Math.PI * 2);
          ctx.stroke();

          // Planet
          const zScale = Math.sin(p.angle) > 0 ? 1.2 : 0.8; // Fake depth
          const alpha = Math.sin(p.angle) > 0 ? 1 : 0.6;
          
          ctx.fillStyle = p.color;
          ctx.globalAlpha = alpha;
          ctx.beginPath();
          ctx.arc(x, y, p.size * zScale, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 1;
        });
      } 
      else if (type === 'ATOMIC') {
        // Nucleus
        const nucPulse = Math.sin(time * 5) * 1;
        ctx.shadowBlur = 30;
        ctx.shadowColor = '#06b6d4';
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(0, 0, 8 + nucPulse, 0, Math.PI * 2);
        ctx.fill();

        // Electrons
        particles.forEach(p => {
          p.angle += p.speed;
          // Rotate orbit
          const x_orbit = Math.cos(p.angle) * p.rx;
          const y_orbit = Math.sin(p.angle) * p.ry;
          
          // Apply tilt rotation
          const x = x_orbit * Math.cos(p.tilt) - y_orbit * Math.sin(p.tilt);
          const y = x_orbit * Math.sin(p.tilt) + y_orbit * Math.cos(p.tilt);

          ctx.fillStyle = p.color;
          ctx.shadowBlur = 10;
          ctx.shadowColor = p.color;
          ctx.beginPath();
          ctx.arc(x, y, 2, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
          
          // Orbit Line
          ctx.strokeStyle = 'rgba(6, 182, 212, 0.1)';
          ctx.beginPath();
          ctx.ellipse(0, 0, p.rx, p.ry, p.tilt, 0, Math.PI * 2);
          ctx.stroke();
        });
      }
      else if (type === 'BIOLOGY') {
        // Double Helix
        particles.forEach(p => {
          const yOffset = p.y;
          const twist = Math.sin(p.angle + time) * 50;
          const depth = Math.cos(p.angle + time);
          
          const alpha = (depth + 1) / 2 * 0.8 + 0.2;
          const size = (depth + 1) * 3 + 2;

          // Strand 1
          ctx.fillStyle = `rgba(236, 72, 153, ${alpha})`;
          ctx.shadowBlur = 10 * alpha;
          ctx.shadowColor = '#ec4899';
          ctx.beginPath();
          ctx.arc(twist, yOffset, size, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
          
          // Strand 2
          ctx.fillStyle = `rgba(16, 185, 129, ${alpha})`;
          ctx.shadowBlur = 10 * alpha;
          ctx.shadowColor = '#10b981';
          ctx.beginPath();
          ctx.arc(-twist, yOffset, size, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;

          // Rungs
          if (depth > -0.2) {
             ctx.strokeStyle = `rgba(255,255,255,${alpha * 0.2})`;
             ctx.beginPath();
             ctx.moveTo(twist, yOffset);
             ctx.lineTo(-twist, yOffset);
             ctx.stroke();
          }
        });
      }
      else if (type === 'GEOMETRY') {
        // Rotating Tesseract-ish Cube
        ctx.strokeStyle = '#8b5cf6';
        ctx.lineWidth = 2;
        ctx.shadowBlur = 15;
        ctx.shadowColor = '#8b5cf6';
        
        const size = 70;
        const rotX = time * 0.4;
        const rotY = time * 0.6;
        
        const points = [];
        for(let x=-1; x<=1; x+=2) {
            for(let y=-1; y<=1; y+=2) {
                for(let z=-1; z<=1; z+=2) {
                    // Rotate
                    let px = x * size;
                    let py = y * size;
                    let pz = z * size;
                    
                    // Rot Y
                    let tx = px * Math.cos(rotY) - pz * Math.sin(rotY);
                    let tz = px * Math.sin(rotY) + pz * Math.cos(rotY);
                    px = tx; pz = tz;

                    // Rot X
                    let ty = py * Math.cos(rotX) - pz * Math.sin(rotX);
                    tz = py * Math.sin(rotX) + pz * Math.cos(rotX);
                    py = ty; pz = tz;
                    
                    points.push({x: px, y: py});
                }
            }
        }
        
        // Connect lines
        ctx.beginPath();
        for(let i=0; i<points.length; i++) {
            for(let j=i+1; j<points.length; j++) {
                const d = Math.sqrt(Math.pow(points[i].x-points[j].x, 2) + Math.pow(points[i].y-points[j].y, 2));
                if (d < size * 2.1 && d > size * 1.9) { 
                    ctx.moveTo(points[i].x, points[i].y);
                    ctx.lineTo(points[j].x, points[j].y);
                }
            }
        }
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
      else {
         // HISTORY / DEFAULT - Rotating Wireframe Globe
         ctx.strokeStyle = '#10b981';
         ctx.lineWidth = 1;
         
         const r = 90;
         // Latitudes
         for(let lat=-90; lat<=90; lat+=15) {
             ctx.beginPath();
             const radLat = lat * Math.PI / 180;
             const rLat = Math.cos(radLat) * r;
             const y = Math.sin(radLat) * r;
             
             for (let ang=0; ang<=360; ang+=5) {
                 const rad = ang * Math.PI / 180;
                 const x = Math.cos(rad + time * 0.5) * rLat;
                 // 3D Tilt effect
                 const xTilt = x; 
                 const yTilt = y * Math.cos(0.3) - (Math.sin(rad + time*0.5)*rLat) * Math.sin(0.3);
                 
                 if (ang===0) ctx.moveTo(xTilt, yTilt);
                 else ctx.lineTo(xTilt, yTilt);
             }
             ctx.stroke();
         }
         
         // Longitudes (approx)
         for (let lng=0; lng<360; lng+=30) {
            ctx.beginPath();
            const radLng = (lng + time * 30) * Math.PI / 180;
             for(let lat=-90; lat<=90; lat+=5) {
                 const radLat = lat * Math.PI / 180;
                 const rLat = Math.cos(radLat) * r;
                 const y = Math.sin(radLat) * r;
                 const x = Math.cos(radLng) * rLat;
                 const z = Math.sin(radLng) * rLat;

                 const xTilt = x;
                 const yTilt = y * Math.cos(0.3) - z * Math.sin(0.3);

                 if(lat===-90) ctx.moveTo(xTilt, yTilt);
                 else ctx.lineTo(xTilt, yTilt);
             }
             ctx.stroke();
         }
      }

      ctx.restore();
      animationFrameId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [type]);

  return <canvas ref={canvasRef} className="w-full h-full opacity-80 mix-blend-screen" />;
};


// --- Main Component ---
export const AIScanner: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [status, setStatus] = useState<'IDLE' | 'SCANNING' | 'RESULT'>('IDLE');
  const [data, setData] = useState<ScanResult | null>(null);
  const [logs, setLogs] = useState<string[]>([]);

  // Simulation of scanning logs
  useEffect(() => {
    if (status === 'SCANNING') {
       const interval = setInterval(() => {
          const commands = [
             "INITIALIZING NEURAL HANDSHAKE...",
             "CONNECTING TO KNOWLEDGE GRAPH...",
             "DECRYPTING CONCEPTS...",
             "SYNTHESIZING VISUAL MATRIX...",
             "RENDERING HOLOGRAPHIC MESH...",
             "CALIBRATING PHYSICS ENGINE...",
             "OPTIMIZING POLYGONS..."
          ];
          const rand = commands[Math.floor(Math.random() * commands.length)];
          setLogs(prev => [...prev.slice(-4), `> ${rand} [OK]`]);
       }, 300);
       return () => clearInterval(interval);
    } else {
       setLogs([]);
    }
  }, [status]);

  const handleScan = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!topic.trim()) return;

    setStatus('SCANNING');
    try {
      const result = await scanTopic(topic);
      setData(result);
      setTimeout(() => setStatus('RESULT'), 2500); 
    } catch (err) {
      alert("Scan failed. Try again.");
      setStatus('IDLE');
    }
  };

  return (
    <div className="h-full bg-[#02040a] relative rounded-3xl overflow-hidden text-cyan-50 font-mono flex flex-col border border-white/10 shadow-2xl">
       
       {/* Ambient Backgrounds */}
       <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/40 via-[#02040a] to-black pointer-events-none"></div>
       <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,255,0.03)_1px,transparent_1px)] bg-[size:60px_60px] pointer-events-none perspective-container transform rotate-x-60"></div>

       {/* Top Status Bar */}
       <div className="h-14 border-b border-white/5 bg-black/40 backdrop-blur-md flex items-center justify-between px-6 z-20">
          <div className="flex items-center gap-3">
             <Hexagon className="w-5 h-5 text-cyan-500 fill-cyan-500/10" />
             <span className="font-bold text-sm tracking-widest text-cyan-100">OMNI-SCANNER v4.0</span>
          </div>
          <div className="flex items-center gap-4 text-[10px] text-gray-500 font-mono">
             <div className="flex items-center gap-1.5">
                <div className={`w-1.5 h-1.5 rounded-full ${status === 'SCANNING' ? 'bg-yellow-500 animate-pulse' : 'bg-green-500'}`}></div>
                SYSTEM {status === 'SCANNING' ? 'BUSY' : 'READY'}
             </div>
             <span className="hidden md:inline">CPU: 12%</span>
             <span className="hidden md:inline">MEM: 4.2GB</span>
          </div>
       </div>

       {/* --- IDLE STATE --- */}
       {status === 'IDLE' && (
         <div className="flex-1 flex flex-col items-center justify-center relative z-10 p-6 animate-fade-in">
            {/* Center Visual */}
            <div className="relative w-64 h-64 mb-12 flex items-center justify-center group">
               {/* Rings */}
               <div className="absolute inset-0 border border-cyan-500/20 rounded-full scale-100 group-hover:scale-110 transition-transform duration-1000"></div>
               <div className="absolute inset-0 border border-indigo-500/20 rounded-full scale-75 animate-pulse-slow"></div>
               <div className="absolute inset-0 border border-white/5 rounded-full scale-125 border-dashed animate-spin-slow"></div>
               
               {/* Core */}
               <div className="relative w-32 h-32 bg-gradient-to-br from-cyan-900/50 to-indigo-900/50 rounded-full backdrop-blur-md border border-cyan-500/30 flex items-center justify-center shadow-[0_0_50px_rgba(6,182,212,0.2)] group-hover:shadow-[0_0_80px_rgba(6,182,212,0.4)] transition-all">
                  <ScanLine className="w-12 h-12 text-cyan-400" strokeWidth={1.5} />
               </div>

               {/* Floating Particles */}
               <div className="absolute top-0 left-1/2 w-1 h-1 bg-white rounded-full animate-ping"></div>
               <div className="absolute bottom-10 right-10 w-1 h-1 bg-indigo-500 rounded-full animate-ping delay-700"></div>
            </div>

            <h1 className="text-4xl md:text-5xl font-black tracking-tight text-white mb-2 text-center">
              What do you want to <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-500">explore?</span>
            </h1>
            <p className="text-gray-400 mb-10 text-center max-w-lg">
               Initialize the neural engine to deconstruct any topic into visual data shards.
            </p>

            <form onSubmit={handleScan} className="w-full max-w-lg relative group">
               <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-500 rounded-xl opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 blur"></div>
               <div className="relative flex items-center bg-[#0B0F19] rounded-xl overflow-hidden border border-white/10 shadow-2xl">
                  <div className="pl-4 pr-3 text-gray-500">
                     <Terminal className="w-5 h-5" />
                  </div>
                  <input 
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Enter concept (e.g. Quantum Physics)..."
                    className="flex-1 bg-transparent py-4 text-white outline-none placeholder-gray-600 font-medium"
                    autoFocus
                  />
                  <button 
                    type="submit"
                    className="px-6 py-4 bg-white/5 hover:bg-white/10 text-white font-bold border-l border-white/10 transition-colors flex items-center gap-2 group/btn"
                  >
                    SCAN <ChevronRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
               </div>
            </form>
         </div>
       )}

       {/* --- SCANNING STATE --- */}
       {status === 'SCANNING' && (
         <div className="flex-1 flex flex-col items-center justify-center relative z-10 p-6 animate-fade-in">
            {/* 3D Wireframe Loader */}
            <div className="relative w-40 h-40 mb-12 perspective-container">
               <div className="w-full h-full border-2 border-cyan-500/50 rounded-lg animate-spin-3d shadow-[0_0_30px_rgba(6,182,212,0.3)] bg-cyan-500/10 backdrop-blur-sm"></div>
               <div className="absolute inset-0 flex items-center justify-center">
                  <Loader2 className="w-10 h-10 text-white animate-spin" />
               </div>
            </div>

            <div className="w-full max-w-md bg-black/50 border border-green-500/30 rounded-lg p-4 font-mono text-xs text-green-400 shadow-inner h-32 flex flex-col justify-end overflow-hidden">
               {logs.map((log, i) => (
                  <div key={i} className="animate-slide-up opacity-80">{log}</div>
               ))}
               <div className="animate-pulse">_</div>
            </div>
         </div>
       )}

       {/* --- RESULT STATE --- */}
       {status === 'RESULT' && data && (
         <div className="flex-1 flex flex-col md:flex-row relative z-10 overflow-hidden animate-fade-in-up">
            
            {/* Left Panel: Info Deck */}
            <div className="w-full md:w-5/12 bg-[#0B0F19]/90 backdrop-blur-xl border-r border-white/10 flex flex-col relative z-20">
               <div className="p-8 flex-1 overflow-y-auto scrollbar-hide">
                  <div className="flex items-start justify-between mb-6">
                     <div>
                        <span className="text-[10px] font-bold text-indigo-400 border border-indigo-500/30 px-2 py-1 rounded mb-3 inline-block bg-indigo-500/10">
                           CLASS: {data.visualType}
                        </span>
                        <h2 className="text-3xl font-black text-white uppercase tracking-tight leading-none">{data.topic}</h2>
                     </div>
                     <Activity className="w-6 h-6 text-cyan-400" />
                  </div>

                  <p className="text-gray-400 leading-relaxed mb-8 border-l-2 border-indigo-500 pl-4">
                     {data.description}
                  </p>

                  <div className="space-y-4">
                     <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Core Analysis</h3>
                     {data.keyPoints.map((point, i) => (
                        <div key={i} className="group flex items-start gap-4 p-4 rounded-xl bg-white/5 border border-white/5 hover:border-cyan-500/30 transition-all">
                           <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center shrink-0 text-cyan-400 font-bold text-sm border border-cyan-500/20">
                              {i + 1}
                           </div>
                           <p className="text-sm text-gray-300 group-hover:text-white transition-colors">{point}</p>
                        </div>
                     ))}
                  </div>
               </div>

               {/* Footer Action */}
               <div className="p-6 border-t border-white/10 bg-black/20">
                  <button 
                     onClick={() => { setStatus('IDLE'); setTopic(''); }}
                     className="w-full py-4 rounded-xl border border-white/10 hover:bg-white/5 text-gray-400 hover:text-white font-bold transition-all flex items-center justify-center gap-2"
                  >
                     <RotateCcw className="w-4 h-4" /> RECALIBRATE SENSORS
                  </button>
               </div>
            </div>

            {/* Right Panel: Hologram Viewport */}
            <div className="flex-1 relative bg-black overflow-hidden flex flex-col">
               {/* Viewport Overlay UI */}
               <div className="absolute top-6 left-6 z-20 flex items-center gap-2">
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-red-500/10 border border-red-500/20 rounded-lg backdrop-blur-md">
                     <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                     <span className="text-[10px] font-bold text-red-400 tracking-wider">LIVE FEED</span>
                  </div>
               </div>
               
               <div className="absolute top-6 right-6 z-20">
                   <Box className="w-6 h-6 text-white/20" />
               </div>

               <div className="absolute bottom-6 left-6 z-20 max-w-xs pointer-events-none">
                  <div className="h-1 w-24 bg-gradient-to-r from-cyan-500 to-transparent mb-2"></div>
                  <p className="text-[10px] text-cyan-500/50 font-mono">
                     RENDERING ENGINE: LUMINA-CORE<br/>
                     POLYGON COUNT: INFINITE
                  </p>
               </div>

               {/* 3D Canvas */}
               <div className="flex-1 relative cursor-move">
                  <HoloProjector type={data.visualType} />
                  {/* CRT/Scanlines Overlay */}
                  <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[size:100%_4px,6px_100%] pointer-events-none opacity-20"></div>
                  <div className="absolute inset-0 bg-radial-gradient from-transparent to-black/60 pointer-events-none"></div>
               </div>
            </div>
         </div>
       )}

       <style>{`
         .perspective-container { perspective: 800px; }
         @keyframes spin-3d {
           0% { transform: rotateX(0deg) rotateY(0deg); }
           100% { transform: rotateX(360deg) rotateY(180deg); }
         }
         .animate-spin-3d { animation: spin-3d 3s linear infinite; }
         .animate-pulse-slow { animation: pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
         .animate-spin-slow { animation: spin 10s linear infinite; }
         .animate-slide-up { animation: slideUp 0.3s ease-out forwards; }
         @keyframes slideUp { from { transform: translateY(10px); opacity: 0; } to { transform: translateY(0); opacity: 0.8; } }
       `}</style>
    </div>
  );
};