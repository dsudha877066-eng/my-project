import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, RefreshCw, Sparkles, Box, Globe, Dna, Cpu, Atom, Zap, Leaf, Cuboid, Mic, Layers, Maximize2 } from 'lucide-react';
import { Message } from '../types';
import { chatWithTutor } from '../services/gemini';
import ReactMarkdown from 'react-markdown';

// --- 3D Avatar Component ---
const LuminaAvatar = ({ state }: { state: 'idle' | 'thinking' }) => {
  return (
    <div className="relative w-24 h-24 flex items-center justify-center perspective-container">
      <style>{`
        .perspective-container { perspective: 1000px; }
        .transform-3d { transform-style: preserve-3d; }
        @keyframes spin-slow { 0% { transform: rotateX(10deg) rotateY(0deg); } 100% { transform: rotateX(10deg) rotateY(360deg); } }
        @keyframes spin-fast { 0% { transform: rotateX(10deg) rotateY(0deg); } 100% { transform: rotateX(10deg) rotateY(720deg); } }
        @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-10px); } }
        @keyframes pulse-core { 0%, 100% { box-shadow: 0 0 20px rgba(99,102,241,0.5); transform: scale(1); } 50% { box-shadow: 0 0 40px rgba(99,102,241,0.8); transform: scale(1.1); } }
      `}</style>
      
      {/* Container for floating effect */}
      <div className="relative w-full h-full animate-float">
        <div className={`relative w-full h-full transform-3d ${state === 'thinking' ? 'animate-spin-fast' : 'animate-spin-slow'}`}>
           {/* Outer Ring */}
           <div className="absolute inset-0 border-2 border-indigo-400/30 rounded-full transform rotateX(60deg)"></div>
           <div className="absolute inset-0 border-2 border-purple-400/30 rounded-full transform rotateY(60deg)"></div>
           <div className="absolute inset-0 border border-cyan-400/50 rounded-full transform rotateX(45deg) rotateY(45deg) scale-110"></div>
           
           {/* Core */}
           <div className="absolute inset-0 m-auto w-8 h-8 bg-white rounded-full animate-pulse-core shadow-[0_0_30px_rgba(255,255,255,0.8)]"></div>
           
           {/* Particles */}
           <div className="absolute top-0 left-1/2 w-2 h-2 bg-blue-400 rounded-full shadow-[0_0_10px_blue] transform -translate-x-1/2 -translate-y-2"></div>
           <div className="absolute bottom-0 right-1/4 w-1.5 h-1.5 bg-purple-400 rounded-full shadow-[0_0_10px_purple]"></div>
        </div>
      </div>
    </div>
  );
};

// --- Interactive 3D Hologram Card ---
const HoloCard = ({ topic, icon: Icon, color, bg }: any) => {
  const [rotate, setRotate] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left; 
    const y = e.clientY - rect.top;
    const cx = rect.width / 2;
    const cy = rect.height / 2;
    // Calculate tilt
    const rx = ((y - cy) / cy) * -15; 
    const ry = ((x - cx) / cx) * 15;
    setRotate({ x: rx, y: ry });
  };

  return (
    <div 
      onMouseMove={handleMouseMove}
      onMouseLeave={() => setRotate({ x: 0, y: 0 })}
      className="relative w-64 h-64 mx-auto my-4 perspective-container group cursor-pointer"
    >
      <div 
        className="w-full h-full relative transform-3d transition-transform duration-100 ease-out border border-white/20 bg-black/40 backdrop-blur-md rounded-2xl overflow-hidden shadow-2xl"
        style={{ transform: `rotateX(${rotate.x}deg) rotateY(${rotate.y}deg)` }}
      >
        {/* Hologram Beam Effect */}
        <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-indigo-500/20 to-transparent pointer-events-none"></div>
        <div className="absolute inset-x-0 bottom-0 h-[1px] bg-indigo-500 shadow-[0_0_20px_rgba(99,102,241,1)]"></div>

        {/* Floating Icon (Pop-out effect) */}
        <div className="absolute inset-0 flex flex-col items-center justify-center transform-3d translate-z-20 group-hover:translate-z-30 transition-transform">
           <div className={`relative w-24 h-24 flex items-center justify-center`}>
              <div className={`absolute inset-0 ${bg} blur-3xl opacity-20 animate-pulse`}></div>
              <Icon className={`w-16 h-16 ${color} drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]`} strokeWidth={1.5} />
           </div>
           <h3 className="text-white font-bold text-lg mt-4 tracking-wider uppercase drop-shadow-md">{topic}</h3>
           <span className="text-[10px] text-indigo-300 font-mono mt-1 border border-indigo-500/30 px-2 py-0.5 rounded bg-indigo-900/40">INTERACTIVE MODEL</span>
        </div>

        {/* Grid Overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none"></div>
      </div>
    </div>
  );
};

// Helper to determine icon and color based on topic
const get3DModelProps = (topic: string) => {
  const t = topic.toLowerCase();
  if (t.includes('dna') || t.includes('gene') || t.includes('cell')) return { icon: Dna, color: 'text-pink-400', bg: 'bg-pink-500' };
  if (t.includes('planet') || t.includes('earth') || t.includes('solar') || t.includes('space') || t.includes('mars')) return { icon: Globe, color: 'text-blue-400', bg: 'bg-blue-500' };
  if (t.includes('cpu') || t.includes('computer') || t.includes('chip') || t.includes('electronic')) return { icon: Cpu, color: 'text-purple-400', bg: 'bg-purple-500' };
  if (t.includes('atom') || t.includes('molecule') || t.includes('physics') || t.includes('proton')) return { icon: Atom, color: 'text-cyan-400', bg: 'bg-cyan-500' };
  if (t.includes('plant') || t.includes('leaf') || t.includes('bio') || t.includes('photosynthesis')) return { icon: Leaf, color: 'text-green-400', bg: 'bg-green-500' };
  if (t.includes('energy') || t.includes('power') || t.includes('electric')) return { icon: Zap, color: 'text-yellow-400', bg: 'bg-yellow-500' };
  if (t.includes('cube') || t.includes('pyramid') || t.includes('shape') || t.includes('geo') || t.includes('sphere')) return { icon: Cuboid, color: 'text-orange-400', bg: 'bg-orange-500' };
  
  return { icon: Box, color: 'text-indigo-400', bg: 'bg-indigo-500' };
};

export const AiTutor: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'model',
      text: "Greetings, Student. I am Lumina, your Holographic Learning Assistant.\n\nAsk me to **visualize** concepts like DNA, the Solar System, or atoms, and I will project them for you. What shall we explore?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (text: string = input) => {
    if (!text.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: text,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const history = messages.slice(-10); 
      const responseText = await chatWithTutor(history, userMsg.text);

      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (error) {
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: "Connection interrupted. Recalibrating systems...",
        timestamp: new Date(),
        isError: true,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Quick Action Chips
  const quickActions = [
    { label: "Visualize DNA", prompt: "Show me a 3D model of DNA and explain its structure." },
    { label: "Solar System", prompt: "Visualize the Solar System planets." },
    { label: "Atomic Structure", prompt: "Show me a 3D model of an Atom." },
    { label: "Quantum Physics", prompt: "Explain Quantum Physics simply." },
  ];

  const renderMessageContent = (msg: Message) => {
    if (msg.role === 'user') {
      return <p className="whitespace-pre-wrap">{msg.text}</p>;
    }

    const threeDMatch = msg.text.match(/\[\[GENERATE_3D_MODEL:\s*(.*?)\]\]/);
    const displayContent = msg.text.replace(/\[\[GENERATE_3D_MODEL:\s*(.*?)\]\]/, '').trim();
    
    return (
      <div className="flex flex-col gap-4">
        <div className="prose prose-sm prose-invert max-w-none prose-p:text-gray-200 prose-headings:text-indigo-300 prose-strong:text-white prose-code:text-cyan-300">
          <ReactMarkdown>
             {displayContent}
          </ReactMarkdown>
        </div>
        
        {threeDMatch && (
           <HoloCard topic={threeDMatch[1]} {...get3DModelProps(threeDMatch[1])} />
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-[calc(100vh-2rem)] bg-[#0B0F19] rounded-2xl shadow-2xl border border-gray-800 overflow-hidden relative">
      
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-indigo-900/20 via-[#0B0F19] to-[#0B0F19] pointer-events-none"></div>
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none opacity-50"></div>

      {/* Header with Avatar */}
      <div className="relative z-10 flex flex-col items-center justify-center pt-6 pb-2 border-b border-gray-800/50 bg-[#0B0F19]/80 backdrop-blur-md">
        <LuminaAvatar state={isLoading ? 'thinking' : 'idle'} />
        <h2 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400 mt-2 tracking-widest uppercase">Lumina Core</h2>
        <p className="text-[10px] text-indigo-400/60 font-mono">SYSTEM ONLINE • READY TO TEACH</p>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-hide relative z-10">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-4 max-w-[90%] ${
              msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''
            }`}
          >
            {/* Icons */}
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg border ${
                msg.role === 'user' 
                  ? 'bg-gradient-to-br from-indigo-600 to-purple-600 border-indigo-400/30' 
                  : 'bg-black/50 border-cyan-500/30 backdrop-blur-md'
              }`}
            >
              {msg.role === 'user' ? (
                <User className="w-5 h-5 text-white" />
              ) : (
                <Bot className="w-5 h-5 text-cyan-400" />
              )}
            </div>

            {/* Bubble */}
            <div
              className={`p-5 rounded-2xl text-sm leading-relaxed shadow-xl backdrop-blur-md border ${
                msg.role === 'user'
                  ? 'bg-indigo-600/90 text-white rounded-tr-none border-indigo-400/30'
                  : msg.isError
                  ? 'bg-red-900/20 text-red-200 border-red-500/30 rounded-tl-none'
                  : 'bg-white/5 text-gray-100 border-white/10 rounded-tl-none shadow-[0_0_15px_rgba(0,0,0,0.3)]'
              }`}
            >
              {renderMessageContent(msg)}
            </div>
          </div>
        ))}
        
        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex items-center gap-3 animate-pulse">
             <div className="w-10 h-10 rounded-full bg-black/50 border border-cyan-500/30 flex items-center justify-center">
                <Bot className="w-5 h-5 text-cyan-400" />
             </div>
             <div className="px-4 py-2 bg-white/5 rounded-full border border-white/10 text-xs text-cyan-400 font-mono flex items-center gap-2">
                <Sparkles className="w-3 h-3 animate-spin" /> PROCESSING DATA...
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input & Quick Actions */}
      <div className="p-4 bg-[#0B0F19]/90 backdrop-blur-xl border-t border-gray-800 relative z-20">
        {/* Chips */}
        {!isLoading && (
          <div className="flex gap-2 overflow-x-auto pb-3 scrollbar-hide mb-2">
            {quickActions.map((action, i) => (
              <button
                key={i}
                onClick={() => handleSend(action.prompt)}
                className="whitespace-nowrap px-4 py-2 bg-indigo-900/30 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 backdrop-blur-sm"
              >
                <Layers className="w-3 h-3" /> {action.label}
              </button>
            ))}
          </div>
        )}

        {/* Input Field */}
        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-cyan-500 rounded-xl opacity-20 group-focus-within:opacity-40 transition-opacity blur"></div>
          <div className="relative flex items-center bg-black/60 rounded-xl border border-white/10 overflow-hidden">
             <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a command or ask to visualize..."
              className="flex-1 bg-transparent px-5 py-4 text-white placeholder-gray-500 focus:outline-none font-medium"
              disabled={isLoading}
            />
            <div className="pr-2 flex items-center gap-1">
              <button className="p-2 text-gray-500 hover:text-cyan-400 transition-colors">
                 <Mic className="w-5 h-5" />
              </button>
              <button
                onClick={() => handleSend()}
                disabled={!input.trim() || isLoading}
                className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg disabled:opacity-50 disabled:bg-gray-700 transition-all shadow-[0_0_10px_rgba(79,70,229,0.4)]"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};