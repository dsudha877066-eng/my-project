import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { BookOpen, Trophy, Clock, Target, ArrowUpRight, Sparkles, Zap, Brain, Rocket } from 'lucide-react';

const mockActivityData = [
  { name: 'Mon', hours: 2.5 },
  { name: 'Tue', hours: 3.8 },
  { name: 'Wed', hours: 1.5 },
  { name: 'Thu', hours: 4.2 },
  { name: 'Fri', hours: 3.0 },
  { name: 'Sat', hours: 5.5 },
  { name: 'Sun', hours: 2.0 },
];

const mockProgressData = [
  { name: 'Math', score: 65 },
  { name: 'Science', score: 85 },
  { name: 'History', score: 45 }, // Weak area
  { name: 'English', score: 78 },
];

export const Dashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-fade-in pb-10">
      
      {/* 3D Animated Hero Section */}
      <div className="relative w-full bg-[#0f172a] rounded-3xl overflow-hidden shadow-2xl p-8 md:p-12 min-h-[380px] flex items-center perspective-container group">
        
        {/* Styles for animations */}
        <style>{`
          .perspective-container { perspective: 1000px; }
          .transform-style-3d { transform-style: preserve-3d; }
          
          @keyframes float-slow {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(2deg); }
          }
          @keyframes float-delayed {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-15px) rotate(-2deg); }
          }
          @keyframes orbit-1 {
            from { transform: rotateX(70deg) rotateZ(0deg); }
            to { transform: rotateX(70deg) rotateZ(360deg); }
          }
          @keyframes orbit-2 {
            from { transform: rotateY(60deg) rotateZ(0deg); }
            to { transform: rotateY(60deg) rotateZ(360deg); }
          }
          @keyframes pulse-glow {
            0%, 100% { box-shadow: 0 0 20px rgba(99,102,241,0.2); transform: scale(1); }
            50% { box-shadow: 0 0 50px rgba(99,102,241,0.5); transform: scale(1.05); }
          }

          .animate-float-slow { animation: float-slow 6s ease-in-out infinite; }
          .animate-float-delayed { animation: float-delayed 7s ease-in-out infinite 1s; }
          .animate-orbit-1 { animation: orbit-1 12s linear infinite; }
          .animate-orbit-2 { animation: orbit-2 15s linear infinite reverse; }
          .animate-pulse-glow { animation: pulse-glow 3s ease-in-out infinite; }
        `}</style>

        {/* Background Gradients */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-950 via-slate-900 to-black opacity-90"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-500/20 via-transparent to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-black/20 to-transparent"></div>

        {/* 3D Composition (Right Side) */}
        <div className="absolute top-0 right-0 w-full md:w-1/2 h-full flex items-center justify-center overflow-visible pointer-events-none hidden md:flex">
           <div className="relative w-64 h-64 transform-style-3d">
              
              {/* Central Core */}
              <div className="absolute inset-0 m-auto w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full animate-pulse-glow flex items-center justify-center z-10 shadow-[0_0_50px_rgba(79,70,229,0.4)]">
                <Brain className="w-10 h-10 text-white opacity-90" />
              </div>

              {/* Orbital Rings */}
              <div className="absolute inset-0 m-auto w-64 h-64 border border-indigo-400/30 rounded-full animate-orbit-1 shadow-[0_0_15px_rgba(99,102,241,0.1)]">
                 <div className="absolute top-0 left-1/2 w-4 h-4 bg-cyan-400 rounded-full shadow-[0_0_15px_cyan] -translate-x-1/2 -translate-y-1/2"></div>
              </div>
              
              <div className="absolute inset-0 m-auto w-48 h-48 border border-purple-400/30 rounded-full animate-orbit-2 shadow-[0_0_15px_rgba(168,85,247,0.1)]">
                 <div className="absolute bottom-0 left-1/2 w-3 h-3 bg-fuchsia-400 rounded-full shadow-[0_0_15px_fuchsia] -translate-x-1/2 translate-y-1/2"></div>
              </div>

              {/* Floating Elements */}
              <div className="absolute -top-12 -right-12 p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 animate-float-slow shadow-xl transform rotate-6">
                 <div className="flex items-center gap-3">
                    <div className="p-2 bg-green-500/20 rounded-lg">
                      <Sparkles className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                      <p className="text-xs text-indigo-200">AI Analysis</p>
                      <p className="text-sm font-bold text-white">Active</p>
                    </div>
                 </div>
              </div>

              <div className="absolute -bottom-8 -left-12 p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 animate-float-delayed shadow-xl transform -rotate-3">
                 <div className="flex items-center gap-3">
                    <div className="p-2 bg-orange-500/20 rounded-lg">
                      <Zap className="w-5 h-5 text-orange-400" />
                    </div>
                    <div>
                      <p className="text-xs text-indigo-200">Daily Streak</p>
                      <p className="text-sm font-bold text-white">3 Days 🔥</p>
                    </div>
                 </div>
              </div>
           </div>
        </div>

        {/* Text Content (Left Side) */}
        <div className="relative z-20 max-w-xl text-white">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 mb-6 backdrop-blur-sm">
             <Rocket className="w-3 h-3 text-indigo-300" />
             <span className="text-xs font-medium text-indigo-200">Lumina AI Learning Engine 2.0</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight tracking-tight">
            Welcome back, <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 via-purple-300 to-cyan-300">Alex J.</span>
          </h1>
          
          <p className="text-indigo-100/80 text-lg mb-8 leading-relaxed max-w-md">
            Your AI Tutor has analyzed your performance. 
            You've improved <span className="text-white font-semibold border-b-2 border-green-400/50">12%</span> in Science this week!
          </p>

          <div className="flex flex-wrap gap-4">
            <button className="px-6 py-3 bg-white text-indigo-900 rounded-xl font-bold hover:bg-indigo-50 transition-colors shadow-lg shadow-indigo-900/20 flex items-center gap-2">
               <BookOpen className="w-4 h-4" />
               Resume Learning
            </button>
            <button className="px-6 py-3 bg-indigo-600/30 text-white border border-indigo-400/30 rounded-xl font-medium hover:bg-indigo-600/50 transition-colors backdrop-blur-sm">
               View Full Report
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          icon={BookOpen} 
          label="Topics Learned" 
          value="12" 
          trend="+3 this week"
          color="blue" 
        />
        <StatCard 
          icon={Clock} 
          label="Study Hours" 
          value="24.5h" 
          trend="On track"
          color="green" 
        />
        <StatCard 
          icon={Trophy} 
          label="Quizzes Aced" 
          value="8" 
          trend="Top 10% class"
          color="yellow" 
        />
        <StatCard 
          icon={Target} 
          label="Current Focus" 
          value="Physics" 
          trend="Next: History"
          color="purple" 
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="xl:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-gray-800">Learning Activity</h2>
            <select className="bg-gray-50 border border-gray-200 text-gray-600 text-sm rounded-lg px-3 py-1 outline-none">
              <option>This Week</option>
              <option>Last Week</option>
            </select>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mockActivityData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="hours" fill="#6366f1" radius={[6, 6, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Secondary Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col">
          <h2 className="text-lg font-bold text-gray-800 mb-6">Subject Mastery</h2>
          <div className="flex-1 min-h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockProgressData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis domain={[0, 100]} axisLine={false} tickLine={false} hide />
                <Tooltip 
                   contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Line type="monotone" dataKey="score" stroke="#10b981" strokeWidth={4} dot={{ r: 4, fill: '#fff', strokeWidth: 2 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 p-4 bg-red-50 rounded-xl border border-red-100 flex items-start gap-3">
            <div className="bg-red-100 p-2 rounded-lg text-red-600">
               <Target className="w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-bold text-gray-800">Action Required</p>
              <p className="text-xs text-gray-600 mt-1">History scores are 15% below target. Schedule a session?</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Recommended Actions */}
      <div>
        <h2 className="text-xl font-bold text-gray-800 mb-4">Recommended for You</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
           <RecommendationCard 
             title="Review Algebra Basics"
             desc="Based on your recent quiz errors."
             color="indigo"
           />
           <RecommendationCard 
             title="Photosynthesis Lab"
             desc="Try a virtual 3D simulation."
             color="green"
           />
           <RecommendationCard 
             title="WWII Timeline"
             desc="Visual history creation task."
             color="orange"
           />
        </div>
      </div>
    </div>
  );
};

// Sub-components for cleaner code
interface StatCardProps {
  icon: React.ElementType;
  label: string;
  value: string;
  trend: string;
  color: 'blue' | 'green' | 'yellow' | 'purple';
}

const StatCard: React.FC<StatCardProps> = ({ icon: Icon, label, value, trend, color }) => {
  const colorMap = {
    blue: 'text-blue-600 bg-blue-50 border-blue-100',
    green: 'text-emerald-600 bg-emerald-50 border-emerald-100',
    yellow: 'text-amber-600 bg-amber-50 border-amber-100',
    purple: 'text-purple-600 bg-purple-50 border-purple-100',
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className={`p-3 rounded-xl ${colorMap[color]} border`}>
          <Icon className="w-6 h-6" />
        </div>
        <span className="text-xs font-medium text-gray-400 bg-gray-50 px-2 py-1 rounded-full">{trend}</span>
      </div>
      <div>
        <p className="text-sm text-gray-500 font-medium mb-1">{label}</p>
        <p className="text-2xl font-bold text-gray-900">{value}</p>
      </div>
    </div>
  );
};

const RecommendationCard = ({ title, desc, color }: { title: string, desc: string, color: string }) => {
   const colorClasses: Record<string, string> = {
      indigo: 'border-indigo-100 bg-indigo-50/50 hover:bg-indigo-50 text-indigo-900',
      green: 'border-green-100 bg-green-50/50 hover:bg-green-50 text-green-900',
      orange: 'border-orange-100 bg-orange-50/50 hover:bg-orange-50 text-orange-900'
   };

   return (
     <div className={`p-5 rounded-2xl border transition-all cursor-pointer ${colorClasses[color]}`}>
       <h3 className="font-bold text-lg mb-1">{title}</h3>
       <p className="text-sm opacity-80">{desc}</p>
     </div>
   );
};