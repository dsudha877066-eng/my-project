import React from 'react';
import { LayoutDashboard, Bot, Calendar, BrainCircuit, GraduationCap, Users, Box, LogOut, Gamepad2, ScanLine } from 'lucide-react';
import { AppView } from '../types';

interface SidebarProps {
  currentView: AppView;
  onChangeView: (view: AppView) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView }) => {
  const menuItems = [
    { id: AppView.DASHBOARD, label: 'Dashboard', icon: LayoutDashboard },
    { id: AppView.AI_SCANNER, label: 'Neural Scanner', icon: ScanLine },
    { id: AppView.GAME, label: 'Game Zone', icon: Gamepad2 },
    { id: AppView.THREE_D_LEARNING, label: 'Holo Lab', icon: Box },
    { id: AppView.TUTOR, label: 'AI Tutor', icon: Bot },
    { id: AppView.PLANNER, label: 'Study Planner', icon: Calendar },
    { id: AppView.QUIZ, label: 'Neural Quiz', icon: BrainCircuit },
    { id: AppView.PARENT_CONNECT, label: 'Guardian Link', icon: Users },
  ];

  return (
    <div className="w-72 h-screen fixed left-0 top-0 hidden md:flex flex-col z-20 font-sans">
      {/* Glassmorphism Background */}
      <div className="absolute inset-0 bg-[#050914]/90 backdrop-blur-2xl border-r border-white/5 shadow-[10px_0_30px_rgba(0,0,0,0.5)]"></div>
      
      {/* Gradient Top Fade */}
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-indigo-900/20 to-transparent pointer-events-none"></div>

      <div className="relative z-10 flex flex-col h-full">
         {/* Brand Logo */}
         <div className="p-8 flex items-center gap-4 mb-2">
           <div className="relative w-12 h-12 flex items-center justify-center">
             <div className="absolute inset-0 bg-indigo-500 blur-xl opacity-40 animate-pulse"></div>
             <div className="relative w-full h-full bg-gradient-to-tr from-indigo-600 to-cyan-600 rounded-xl flex items-center justify-center shadow-lg border border-white/10">
               <GraduationCap className="w-6 h-6 text-white" />
             </div>
           </div>
           <div>
             <h1 className="text-2xl font-black text-white tracking-tight">Lumina<span className="text-cyan-400">.AI</span></h1>
             <div className="flex items-center gap-1.5 mt-0.5">
               <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
               <p className="text-[10px] text-indigo-300 font-mono uppercase tracking-wider">System Online</p>
             </div>
           </div>
         </div>

         {/* Navigation */}
         <nav className="flex-1 px-4 space-y-2 overflow-y-auto scrollbar-hide">
           <p className="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-4 mt-2">Main Modules</p>
           {menuItems.map((item) => {
             const Icon = item.icon;
             const isActive = currentView === item.id;
             return (
               <button
                 key={item.id}
                 onClick={() => onChangeView(item.id)}
                 className={`relative w-full flex items-center gap-4 px-4 py-4 rounded-xl transition-all duration-300 group overflow-hidden ${
                   isActive
                     ? 'bg-white/5 text-white shadow-[0_0_20px_rgba(99,102,241,0.15)] border border-indigo-500/30'
                     : 'text-gray-400 hover:text-white hover:bg-white/5 border border-transparent'
                 }`}
               >
                 {/* Active Indicator Line */}
                 {isActive && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-cyan-400 rounded-r-full shadow-[0_0_10px_cyan]"></div>
                 )}

                 {/* Hover Gradient Effect */}
                 <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                 {/* Icon Container */}
                 <div className={`relative p-2 rounded-lg transition-all duration-300 ${isActive ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/40' : 'bg-white/5 text-gray-500 group-hover:bg-indigo-500/20 group-hover:text-indigo-300 group-hover:scale-110'}`}>
                    <Icon className="w-5 h-5" strokeWidth={2} />
                 </div>
                 
                 <span className={`font-medium tracking-wide transition-all ${isActive ? 'translate-x-1' : 'group-hover:translate-x-1'}`}>
                    {item.label}
                 </span>

                 {/* Active Sparkle */}
                 {isActive && (
                    <div className="absolute right-4 w-1.5 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_5px_cyan] animate-pulse"></div>
                 )}
               </button>
             );
           })}
         </nav>

         {/* Bottom Card */}
         <div className="p-4 mt-auto">
           <div className="relative overflow-hidden rounded-2xl bg-[#0F1420] border border-white/5 p-5 group cursor-pointer hover:border-indigo-500/30 transition-colors">
             <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 blur-3xl rounded-full transform translate-x-10 -translate-y-10 group-hover:bg-indigo-500/20 transition-all"></div>
             
             <div className="flex items-center justify-between mb-3 relative z-10">
               <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Daily Streak</p>
               <Box className="w-4 h-4 text-indigo-500" />
             </div>
             
             <div className="flex items-end gap-2 mb-3 relative z-10">
               <h3 className="text-3xl font-black text-white">3</h3>
               <span className="text-sm font-medium text-gray-400 mb-1">Days</span>
             </div>
             
             <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden relative z-10">
               <div className="bg-gradient-to-r from-indigo-500 to-cyan-400 w-[60%] h-full rounded-full shadow-[0_0_10px_indigo]"></div>
             </div>
           </div>
           
           <button className="w-full flex items-center gap-2 px-4 py-4 text-sm font-bold text-gray-500 hover:text-red-400 transition-colors mt-2 justify-center hover:bg-red-500/5 rounded-xl">
             <LogOut className="w-4 h-4" strokeWidth={2.5} />
             <span>Terminate Session</span>
           </button>
         </div>
      </div>
    </div>
  );
};